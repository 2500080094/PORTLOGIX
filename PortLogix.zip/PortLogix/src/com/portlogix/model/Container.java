package com.portlogix.model;

/**
 * Represents a shipping container in PortLogix.
 * Adheres to ISO 6346 identification standards (e.g., MSKU9012347).
 */
public class Container implements Comparable<Container> {
    private final String id;
    private final String vesselImo;
    private final double weightMt; // Metric tonnes
    private final String hazardClass;
    private final int dwellHours;
    private final int priorityScore; // 1-100 (higher = more urgent)
    private String status;

    public Container(String id, String vesselImo, double weightMt, String hazardClass, 
                     int dwellHours, int priorityScore, String status) {
        this.id = id;
        this.vesselImo = vesselImo;
        this.weightMt = weightMt;
        this.hazardClass = hazardClass != null ? hazardClass : "NONE";
        this.dwellHours = dwellHours;
        this.priorityScore = priorityScore;
        this.status = status != null ? status : "STORED";
    }

    public String getId() { return id; }
    public String getVesselImo() { return vesselImo; }
    public double getWeightMt() { return weightMt; }
    public String getHazardClass() { return hazardClass; }
    public int getDwellHours() { return dwellHours; }
    public int getPriorityScore() { return priorityScore; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public boolean isHazardous() {
        return !hazardClass.equalsIgnoreCase("NONE") && !hazardClass.isEmpty();
    }

    @Override
    public int compareTo(Container other) {
        // Natural ordering: highest priority first, then lowest dwell hours
        int cmp = Integer.compare(other.priorityScore, this.priorityScore);
        if (cmp != 0) return cmp;
        return this.id.compareTo(other.id);
    }

    @Override
    public String toString() {
        return String.format("[%s | %.1f MT | %s | Prio:%d | Dwell:%dh | %s]",
                id, weightMt, hazardClass, priorityScore, dwellHours, status);
    }
}
