package com.portlogix.model;

/**
 * Encapsulates a shipment record from cargo documents, containing tracking codes,
 * container references, and document text.
 */
public class ShipmentRecord {
    private final String manifestId;
    private final String containerId;
    private final String trackingCode;
    private final String description;
    private final String origin;
    private final String destination;

    public ShipmentRecord(String manifestId, String containerId, String trackingCode, 
                          String description, String origin, String destination) {
        this.manifestId = manifestId;
        this.containerId = containerId;
        this.trackingCode = trackingCode;
        this.description = description;
        this.origin = origin;
        this.destination = destination;
    }

    public String getManifestId() { return manifestId; }
    public String getContainerId() { return containerId; }
    public String getTrackingCode() { return trackingCode; }
    public String getDescription() { return description; }
    public String getOrigin() { return origin; }
    public String getDestination() { return destination; }

    @Override
    public String toString() {
        return String.format("[%s | %s | %s -> %s | '%s']", 
                manifestId, containerId, origin, destination, trackingCode);
    }
}
