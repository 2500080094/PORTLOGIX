package com.portlogix.model;

/**
 * Represents a physical or operational node in the port infrastructure.
 */
public class PortFacility {
    public enum FacilityType {
        BERTH, QUAY_CRANE, BUFFER_YARD, HAZMAT_SHED, SCANNER_COMPLEX, RAIL_TERMINAL, GATE_EXIT
    }

    private final int id;
    private final String name;
    private final FacilityType type;
    private final int maxThroughputTeuPerHour;

    public PortFacility(int id, String name, FacilityType type, int maxThroughputTeuPerHour) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.maxThroughputTeuPerHour = maxThroughputTeuPerHour;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public FacilityType getType() { return type; }
    public int getMaxThroughputTeuPerHour() { return maxThroughputTeuPerHour; }

    @Override
    public String toString() {
        return String.format("#%d %s (%s, Cap:%d TEU/h)", id, name, type, maxThroughputTeuPerHour);
    }
}
