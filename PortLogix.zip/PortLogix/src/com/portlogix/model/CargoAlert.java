package com.portlogix.model;

/**
 * Represents an alert match identified by pattern matching engines (e.g. Aho-Corasick).
 */
public class CargoAlert {
    private final String pattern;
    private final int position;
    private final String severity; // CRITICAL, WARNING, INFO
    private final String contextSnippet;

    public CargoAlert(String pattern, int position, String severity, String contextSnippet) {
        this.pattern = pattern;
        this.position = position;
        this.severity = severity;
        this.contextSnippet = contextSnippet;
    }

    public String getPattern() { return pattern; }
    public int getPosition() { return position; }
    public String getSeverity() { return severity; }
    public String getContextSnippet() { return contextSnippet; }

    @Override
    public String toString() {
        return String.format("[%s ALERT at pos %d] Pattern: '%s' | Context: \"...%s...\"", 
                severity, position, pattern, contextSnippet);
    }
}
