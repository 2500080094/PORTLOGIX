package com.portlogix.model;

/**
 * Represents a maritime container vessel calling at PortLogix berths.
 */
public class Vessel {
    private final String imoNumber;
    private final String name;
    private final int capacityTeu;
    private final double draftMeters;
    private String assignedBerth;

    public Vessel(String imoNumber, String name, int capacityTeu, double draftMeters, String assignedBerth) {
        this.imoNumber = imoNumber;
        this.name = name;
        this.capacityTeu = capacityTeu;
        this.draftMeters = draftMeters;
        this.assignedBerth = assignedBerth;
    }

    public String getImoNumber() { return imoNumber; }
    public String getName() { return name; }
    public int getCapacityTeu() { return capacityTeu; }
    public double getDraftMeters() { return draftMeters; }
    public String getAssignedBerth() { return assignedBerth; }
    public void setAssignedBerth(String assignedBerth) { this.assignedBerth = assignedBerth; }

    @Override
    public String toString() {
        return String.format("Vessel[%s, IMO:%s, Cap:%d TEU, Berth:%s]", 
                name, imoNumber, capacityTeu, assignedBerth);
    }
}
