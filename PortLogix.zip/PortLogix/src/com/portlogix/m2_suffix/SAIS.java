package com.portlogix.m2_suffix;

import java.util.Arrays;

/**
 * Module 2 (M2 - CO2): Suffix Structures – Document Similarity
 * SA-IS (Suffix Array Induced Sorting) Algorithm.
 * 
 * PortLogix Use Case:
 * Ultra-fast linear time O(N) indexing of gigabyte-scale port manifests,
 * vessel tracking archives, and sensor telemetry logs.
 * Time Complexity: Guaranteed strictly O(N).
 */
public class SAIS {

    private static final boolean S_TYPE = false;
    private static final boolean L_TYPE = true;

    /**
     * Builds Suffix Array in linear O(N) time using SA-IS.
     */
    public static int[] build(String s) {
        if (s == null || s.isEmpty()) return new int[0];
        int n = s.length();
        int[] text = new int[n + 1];
        int maxChar = 0;
        for (int i = 0; i < n; i++) {
            text[i] = s.charAt(i) + 1; // 1-based to leave 0 for sentinel
            maxChar = Math.max(maxChar, text[i]);
        }
        text[n] = 0; // Sentinel ($) smaller than all characters
        maxChar++;

        int[] sa = sais(text, maxChar);

        // Discard sentinel position (sa[0])
        int[] result = new int[n];
        System.arraycopy(sa, 1, result, 0, n);
        return result;
    }

    private static int[] sais(int[] s, int K) {
        int n = s.length;
        if (n == 1) return new int[]{0};
        if (n == 2) {
            if (s[0] < s[1]) return new int[]{0, 1};
            return new int[]{1, 0};
        }

        boolean[] type = new boolean[n]; // false: S_TYPE, true: L_TYPE
        type[n - 1] = S_TYPE;
        for (int i = n - 2; i >= 0; i--) {
            if (s[i] < s[i + 1]) {
                type[i] = S_TYPE;
            } else if (s[i] > s[i + 1]) {
                type[i] = L_TYPE;
            } else {
                type[i] = type[i + 1];
            }
        }

        int[] bucket = getBuckets(s, K);
        int[] sa = new int[n];
        Arrays.fill(sa, -1);

        // Find LMS characters
        int[] lms = new int[n];
        int lmsCount = 0;
        for (int i = 1; i < n; i++) {
            if (type[i] == S_TYPE && type[i - 1] == L_TYPE) {
                lms[lmsCount++] = i;
            }
        }

        // 1. Put LMS suffixes into SA
        int[] bkt = Arrays.copyOf(bucket, bucket.length);
        for (int i = 0; i < lmsCount; i++) {
            int pos = lms[i];
            sa[bkt[s[pos]]--] = pos;
        }

        // 2. Induce sort L-type and S-type
        induceSort(s, sa, type, bucket, K);

        // 3. Compact LMS suffixes into beginning of SA
        int[] lmsMap = new int[n];
        Arrays.fill(lmsMap, -1);
        for (int i = 0; i < lmsCount; i++) {
            lmsMap[lms[i]] = i;
        }

        int cur = 0;
        for (int i = 0; i < n; i++) {
            if (lmsMap[sa[i]] != -1) {
                sa[cur++] = sa[i];
            }
        }

        // 4. Name LMS substrings
        int[] s1 = new int[lmsCount];
        int name = 0;
        s1[lmsMap[sa[0]]] = name;
        for (int i = 1; i < lmsCount; i++) {
            int pos1 = sa[i];
            int pos2 = sa[i - 1];
            if (!isLmsSubstringEqual(s, type, pos1, pos2)) {
                name++;
            }
            s1[lmsMap[pos1]] = name;
        }

        int[] sa1;
        if (name < lmsCount - 1) {
            sa1 = sais(s1, name + 1);
        } else {
            sa1 = new int[lmsCount];
            for (int i = 0; i < lmsCount; i++) {
                sa1[s1[i]] = i;
            }
        }

        // 5. Place sorted LMS suffixes back into SA
        Arrays.fill(sa, -1);
        bkt = Arrays.copyOf(bucket, bucket.length);
        for (int i = lmsCount - 1; i >= 0; i--) {
            int pos = lms[sa1[i]];
            sa[bkt[s[pos]]--] = pos;
        }

        // 6. Final induce sort
        induceSort(s, sa, type, bucket, K);
        return sa;
    }

    private static boolean isLmsSubstringEqual(int[] s, boolean[] type, int p1, int p2) {
        int i = 0;
        while (true) {
            boolean isLms1 = (i > 0 && type[p1 + i] == S_TYPE && type[p1 + i - 1] == L_TYPE);
            boolean isLms2 = (i > 0 && type[p2 + i] == S_TYPE && type[p2 + i - 1] == L_TYPE);
            if (i > 0 && isLms1 && isLms2) return true;
            if (isLms1 != isLms2) return false;
            if (s[p1 + i] != s[p2 + i] || type[p1 + i] != type[p2 + i]) return false;
            i++;
        }
    }

    private static void induceSort(int[] s, int[] sa, boolean[] type, int[] bucket, int K) {
        int n = s.length;
        // Induce L-type
        int[] bkt = getBucketHeads(s, K);
        for (int i = 0; i < n; i++) {
            int j = sa[i] - 1;
            if (j >= 0 && type[j] == L_TYPE) {
                sa[bkt[s[j]]++] = j;
            }
        }

        // Induce S-type
        bkt = Arrays.copyOf(bucket, bucket.length);
        for (int i = n - 1; i >= 0; i--) {
            int j = sa[i] - 1;
            if (j >= 0 && type[j] == S_TYPE) {
                sa[bkt[s[j]]--] = j;
            }
        }
    }

    private static int[] getBuckets(int[] s, int K) {
        int[] bkt = new int[K];
        for (int v : s) bkt[v]++;
        for (int i = 1; i < K; i++) bkt[i] += bkt[i - 1];
        for (int i = 0; i < K; i++) bkt[i]--;
        return bkt;
    }

    private static int[] getBucketHeads(int[] s, int K) {
        int[] count = new int[K];
        for (int v : s) count[v]++;
        int[] heads = new int[K];
        int sum = 0;
        for (int i = 0; i < K; i++) {
            heads[i] = sum;
            sum += count[i];
        }
        return heads;
    }
}
