package com.portlogix.m2_suffix;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Module 2 (M2 - CO2): Suffix Structures – Document Similarity
 * Suffix Array implementation with Prefix Doubling (O(N log^2 N))
 * and binary search substring matching O(M log N).
 * 
 * PortLogix Use Case:
 * Indexing vast repositories of bills of lading, customs declarations,
 * and container inspection logs for instantaneous substring lookups.
 */
public class SuffixArray {
    private final String text;
    private final int[] sa; // Suffix Array: sa[i] is the starting index of the i-th lexicographical suffix

    public SuffixArray(String text) {
        this.text = text != null ? text : "";
        this.sa = buildSuffixArray(this.text);
    }

    public SuffixArray(String text, int[] customSa) {
        this.text = text != null ? text : "";
        this.sa = customSa;
    }

    public int[] getSa() { return sa; }
    public String getText() { return text; }
    public int length() { return text.length(); }

    /**
     * Standard prefix-doubling suffix array construction.
     */
    private int[] buildSuffixArray(String s) {
        int n = s.length();
        if (n == 0) return new int[0];

        Integer[] order = new Integer[n];
        for (int i = 0; i < n; i++) order[i] = i;

        int[] rank = new int[n];
        for (int i = 0; i < n; i++) rank[i] = s.charAt(i);

        int[] nextRank = new int[n];

        for (int k = 1; k < n; k <<= 1) {
            final int len = k;
            final int[] currRank = rank;
            Arrays.sort(order, (a, b) -> {
                if (currRank[a] != currRank[b]) {
                    return Integer.compare(currRank[a], currRank[b]);
                }
                int ra = (a + len < n) ? currRank[a + len] : -1;
                int rb = (b + len < n) ? currRank[b + len] : -1;
                return Integer.compare(ra, rb);
            });

            nextRank[order[0]] = 0;
            for (int i = 1; i < n; i++) {
                int prev = order[i - 1];
                int curr = order[i];
                boolean sameFirst = currRank[prev] == currRank[curr];
                int rPrev = (prev + len < n) ? currRank[prev + len] : -1;
                int rCurr = (curr + len < n) ? currRank[curr + len] : -1;
                boolean sameSecond = rPrev == rCurr;

                nextRank[curr] = (sameFirst && sameSecond) ? nextRank[prev] : nextRank[prev] + 1;
            }
            rank = Arrays.copyOf(nextRank, n);
            if (rank[order[n - 1]] == n - 1) break;
        }

        int[] result = new int[n];
        for (int i = 0; i < n; i++) result[i] = order[i];
        return result;
    }

    /**
     * Finds all occurrence indices of query pattern in text using binary search on Suffix Array.
     * Time Complexity: O(m * log n)
     */
    public List<Integer> search(String query) {
        List<Integer> matches = new ArrayList<>();
        if (query == null || query.isEmpty() || sa.length == 0) return matches;

        int n = text.length();
        int m = query.length();

        // Binary search lower bound
        int low = 0, high = n - 1;
        int first = -1;
        while (low <= high) {
            int mid = (low + high) >>> 1;
            int cmp = compareSuffixWithQuery(sa[mid], query);
            if (cmp >= 0) {
                if (cmp == 0) first = mid;
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }

        if (first == -1) return matches;

        // Binary search upper bound
        low = first;
        high = n - 1;
        int last = first;
        while (low <= high) {
            int mid = (low + high) >>> 1;
            int cmp = compareSuffixWithQuery(sa[mid], query);
            if (cmp == 0) {
                last = mid;
                low = mid + 1;
            } else if (cmp < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        for (int i = first; i <= last; i++) {
            matches.add(sa[i]);
        }
        return matches;
    }

    private int compareSuffixWithQuery(int suffixStart, String query) {
        int n = text.length();
        int m = query.length();
        int len = Math.min(n - suffixStart, m);
        for (int i = 0; i < len; i++) {
            char c1 = text.charAt(suffixStart + i);
            char c2 = query.charAt(i);
            if (c1 != c2) return Character.compare(c1, c2);
        }
        if (n - suffixStart < m) return -1;
        return 0; // Prefix of suffix matches query completely
    }
}
