package com.portlogix.m2_suffix;

import java.util.HashMap;
import java.util.Map;

/**
 * Module 2 (M2 - CO2): Suffix Structures – Document Similarity
 * Suffix Automaton (SAM / Directed Acyclic Word Graph - DAWG).
 * 
 * PortLogix Use Case:
 * Instantaneous substring recognition, counting distinct cargo phrases,
 * and finding longest common substrings across streaming logistics records.
 * Construction Time: Strictly linear O(N).
 * Query Time: O(|pattern|).
 */
public class SuffixAutomaton {

    public static class State {
        public int len;
        public int link;
        public Map<Character, Integer> next = new HashMap<>();

        public State(int len, int link) {
            this.len = len;
            this.link = link;
        }
    }

    private State[] st;
    private int sz;
    private int last;

    public SuffixAutomaton(String s) {
        int maxStates = Math.max(2, 2 * s.length() + 1);
        st = new State[maxStates];
        st[0] = new State(0, -1);
        sz = 1;
        last = 0;

        for (int i = 0; i < s.length(); i++) {
            extend(s.charAt(i));
        }
    }

    private void extend(char c) {
        int cur = sz++;
        st[cur] = new State(st[last].len + 1, 0);

        int p = last;
        while (p != -1 && !st[p].next.containsKey(c)) {
            st[p].next.put(c, cur);
            p = st[p].link;
        }

        if (p == -1) {
            st[cur].link = 0;
        } else {
            int q = st[p].next.get(c);
            if (st[p].len + 1 == st[q].len) {
                st[cur].link = q;
            } else {
                int clone = sz++;
                st[clone] = new State(st[p].len + 1, st[q].link);
                st[clone].next.putAll(st[q].next);

                while (p != -1 && st[p].next.get(c) == q) {
                    st[p].next.put(c, clone);
                    p = st[p].link;
                }
                st[q].link = clone;
                st[cur].link = clone;
            }
        }
        last = cur;
    }

    /**
     * Checks if a pattern is a substring in O(|pattern|) time.
     */
    public boolean containsSubstring(String pattern) {
        if (pattern == null) return false;
        int curr = 0;
        for (int i = 0; i < pattern.length(); i++) {
            char c = pattern.charAt(i);
            if (!st[curr].next.containsKey(c)) {
                return false;
            }
            curr = st[curr].next.get(c);
        }
        return true;
    }

    /**
     * Computes the number of distinct substrings in the indexed document.
     */
    public long countDistinctSubstrings() {
        long total = 0;
        for (int i = 1; i < sz; i++) {
            total += st[i].len - st[st[i].link].len;
        }
        return total;
    }

    /**
     * Finds the longest common substring between the indexed string and a query string.
     */
    public String longestCommonSubstring(String query) {
        if (query == null || query.isEmpty()) return "";
        int v = 0, l = 0, best = 0, bestPos = 0;

        for (int i = 0; i < query.length(); i++) {
            char c = query.charAt(i);
            while (v != 0 && !st[v].next.containsKey(c)) {
                v = st[v].link;
                l = st[v].len;
            }
            if (st[v].next.containsKey(c)) {
                v = st[v].next.get(c);
                l++;
            }
            if (l > best) {
                best = l;
                bestPos = i;
            }
        }
        return query.substring(bestPos - best + 1, bestPos + 1);
    }

    public int getStateCount() {
        return sz;
    }
}
