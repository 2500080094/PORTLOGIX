package com.portlogix.m2_suffix;

/**
 * Module 2 (M2 - CO2): Suffix Structures – Document Similarity
 * Kasai's LCP (Longest Common Prefix) Algorithm.
 * 
 * PortLogix Use Case:
 * Identifying duplicate cargo descriptions, common contractual clauses,
 * and measuring document similarity across shipping bills in linear O(N) time.
 */
public class KasaiLCP {

    /**
     * Computes the LCP array in linear O(N) time using Kasai's algorithm.
     * lcp[i] = length of the longest common prefix of suffixes sa[i] and sa[i - 1].
     * (lcp[0] is set to 0).
     */
    public static int[] computeLCP(String text, int[] sa) {
        if (text == null || sa == null || sa.length == 0) return new int[0];
        int n = text.length();
        int[] lcp = new int[n];
        int[] rank = new int[n];

        for (int i = 0; i < n; i++) {
            rank[sa[i]] = i;
        }

        int h = 0;
        for (int i = 0; i < n; i++) {
            if (rank[i] > 0) {
                int j = sa[rank[i] - 1]; // Preceding suffix in lexicographical order
                while (i + h < n && j + h < n && text.charAt(i + h) == text.charAt(j + h)) {
                    h++;
                }
                lcp[rank[i]] = h;
                if (h > 0) {
                    h--;
                }
            }
        }
        return lcp;
    }

    /**
     * Finds the Longest Repeated Substring (LRS) in the text using LCP array.
     */
    public static String findLongestRepeatedSubstring(String text, int[] sa, int[] lcp) {
        if (lcp == null || lcp.length == 0 || text == null) return "";
        int maxLen = 0;
        int maxIndex = -1;

        for (int i = 1; i < lcp.length; i++) {
            if (lcp[i] > maxLen) {
                maxLen = lcp[i];
                maxIndex = sa[i];
            }
        }

        if (maxIndex != -1 && maxLen > 0) {
            return text.substring(maxIndex, maxIndex + maxLen);
        }
        return "";
    }

    /**
     * Evaluates similarity between two cargo documents by concatenating them with a separator
     * and computing the maximum shared common substring length using LCP.
     */
    public static String findLongestCommonSubstring(String doc1, String doc2) {
        if (doc1 == null || doc2 == null || doc1.isEmpty() || doc2.isEmpty()) return "";
        String combined = doc1 + "#" + doc2;
        int[] sa = SAIS.build(combined);
        int[] lcp = computeLCP(combined, sa);

        int maxLen = 0;
        int maxPos = -1;
        int split = doc1.length();

        for (int i = 1; i < lcp.length; i++) {
            boolean firstInDoc1 = sa[i] < split;
            boolean secondInDoc1 = sa[i - 1] < split;

            // One suffix starts in doc1 and the other in doc2
            if (firstInDoc1 != secondInDoc1 && lcp[i] > maxLen) {
                maxLen = lcp[i];
                maxPos = sa[i];
            }
        }

        if (maxPos != -1 && maxLen > 0) {
            return combined.substring(maxPos, maxPos + maxLen);
        }
        return "";
    }
}
