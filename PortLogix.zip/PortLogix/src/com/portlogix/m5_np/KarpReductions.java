package com.portlogix.m5_np;

import java.util.*;

/**
 * Module 5 (M5 - CO5): NP-Completeness and Computational Reductions
 * Formal Karp Reductions:
 * 1. 3-SAT -> CLIQUE
 * 2. CLIQUE -> INDEPENDENT SET
 * 3. INDEPENDENT SET -> VERTEX COVER
 * 
 * PortLogix Use Case:
 * Modeling port resource scheduling and conflict avoidance. When berths or cranes have
 * mutual exclusion constraints, this demonstrates the polynomial-time equivalence of
 * solving constraint satisfaction via graph theoretic problem formulations.
 */
public class KarpReductions {

    public static class UndirectedGraph {
        public final int numVertices;
        public final boolean[][] adj;
        public final String[] labels;

        public UndirectedGraph(int numVertices) {
            this.numVertices = numVertices;
            this.adj = new boolean[numVertices][numVertices];
            this.labels = new String[numVertices];
            for (int i = 0; i < numVertices; i++) {
                labels[i] = "v" + i;
            }
        }

        public void addEdge(int u, int v) {
            if (u != v && u >= 0 && u < numVertices && v >= 0 && v < numVertices) {
                adj[u][v] = true;
                adj[v][u] = true;
            }
        }

        public boolean hasEdge(int u, int v) {
            return adj[u][v];
        }

        /**
         * Computes the complement graph G_bar where (u, v) in E_bar iff (u, v) not in E.
         */
        public UndirectedGraph complement() {
            UndirectedGraph comp = new UndirectedGraph(numVertices);
            for (int i = 0; i < numVertices; i++) {
                comp.labels[i] = this.labels[i];
                for (int j = i + 1; j < numVertices; j++) {
                    if (!this.adj[i][j]) {
                        comp.addEdge(i, j);
                    }
                }
            }
            return comp;
        }

        /**
         * Verifies if a given subset of vertices forms a valid Vertex Cover.
         */
        public boolean isVertexCover(Set<Integer> cover) {
            for (int i = 0; i < numVertices; i++) {
                for (int j = i + 1; j < numVertices; j++) {
                    if (adj[i][j] && !cover.contains(i) && !cover.contains(j)) {
                        return false;
                    }
                }
            }
            return true;
        }

        /**
         * Verifies if a given subset of vertices forms an Independent Set.
         */
        public boolean isIndependentSet(Set<Integer> is) {
            List<Integer> list = new ArrayList<>(is);
            for (int i = 0; i < list.size(); i++) {
                for (int j = i + 1; j < list.size(); j++) {
                    if (adj[list.get(i)][list.get(j)]) {
                        return false;
                    }
                }
            }
            return true;
        }

        /**
         * Verifies if a given subset of vertices forms a Clique.
         */
        public boolean isClique(Set<Integer> clique) {
            List<Integer> list = new ArrayList<>(clique);
            for (int i = 0; i < list.size(); i++) {
                for (int j = i + 1; j < list.size(); j++) {
                    if (!adj[list.get(i)][list.get(j)]) {
                        return false;
                    }
                }
            }
            return true;
        }
    }

    public static class CliqueReductionInstance {
        public final UndirectedGraph graph;
        public final int targetK;
        public final Map<Integer, int[]> vertexToClauseLiteral; // vertexId -> [clauseIdx, literalVal]

        public CliqueReductionInstance(UndirectedGraph graph, int targetK, Map<Integer, int[]> map) {
            this.graph = graph;
            this.targetK = targetK;
            this.vertexToClauseLiteral = map;
        }
    }

    /**
     * Karp Reduction: 3-SAT -> CLIQUE.
     * Given a 3-SAT formula with k clauses, constructs a graph with 3*k vertices
     * such that the formula is satisfiable iff G contains a clique of size k.
     */
    public static CliqueReductionInstance reduce3SatToClique(List<PortSatSolver.Clause> clauses) {
        int k = clauses.size();
        int totalVertices = 0;
        for (PortSatSolver.Clause c : clauses) {
            totalVertices += c.literals.length;
        }

        UndirectedGraph g = new UndirectedGraph(totalVertices);
        Map<Integer, int[]> mapping = new HashMap<>();

        // Create vertices
        int vid = 0;
        for (int cIdx = 0; cIdx < k; cIdx++) {
            PortSatSolver.Clause c = clauses.get(cIdx);
            for (int lit : c.literals) {
                g.labels[vid] = String.format("C%d[%s]", cIdx + 1, lit > 0 ? "x" + lit : "¬x" + (-lit));
                mapping.put(vid, new int[]{cIdx, lit});
                vid++;
            }
        }

        // Add edges: between different clauses when literals are consistent (not negations)
        for (int u = 0; u < totalVertices; u++) {
            int[] uInfo = mapping.get(u);
            int uClause = uInfo[0];
            int uLit = uInfo[1];

            for (int v = u + 1; v < totalVertices; v++) {
                int[] vInfo = mapping.get(v);
                int vClause = vInfo[0];
                int vLit = vInfo[1];

                if (uClause != vClause && uLit != -vLit) {
                    g.addEdge(u, v);
                }
            }
        }

        return new CliqueReductionInstance(g, k, mapping);
    }

    /**
     * Karp Reduction: CLIQUE -> INDEPENDENT SET.
     * Graph G has a clique of size k iff G_bar (complement) has an independent set of size k.
     */
    public static UndirectedGraph reduceCliqueToIndependentSet(UndirectedGraph g) {
        return g.complement();
    }

    /**
     * Karp Reduction: INDEPENDENT SET -> VERTEX COVER.
     * In graph H, S is an Independent Set of size k iff V \ S is a Vertex Cover of size |V| - k.
     */
    public static Set<Integer> independentSetToVertexCover(UndirectedGraph h, Set<Integer> independentSet) {
        Set<Integer> vertexCover = new HashSet<>();
        for (int i = 0; i < h.numVertices; i++) {
            if (!independentSet.contains(i)) {
                vertexCover.add(i);
            }
        }
        return vertexCover;
    }

    public static Set<Integer> vertexCoverToIndependentSet(UndirectedGraph h, Set<Integer> vertexCover) {
        Set<Integer> independentSet = new HashSet<>();
        for (int i = 0; i < h.numVertices; i++) {
            if (!vertexCover.contains(i)) {
                independentSet.add(i);
            }
        }
        return independentSet;
    }
}
