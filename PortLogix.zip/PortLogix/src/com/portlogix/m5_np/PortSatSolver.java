package com.portlogix.m5_np;

import java.util.*;

/**
 * Module 5 (M5 - CO5): NP-Completeness and Approximation
 * 3-SAT / CNF-SAT Solver using DPLL (Davis-Putnam-Logemann-Loveland).
 * 
 * PortLogix Use Case:
 * Solving complex regulatory constraints in smart-port operations, such as
 * mutual hazardous material segregation, reefer power phase balancing,
 * and crane non-collision schedules.
 */
public class PortSatSolver {

    public static class Clause {
        // Positive integers: x_1, x_2, ...
        // Negative integers: -x_1, -x_2, ...
        public final int[] literals;

        public Clause(int... literals) {
            this.literals = literals;
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder("(");
            for (int i = 0; i < literals.length; i++) {
                int lit = literals[i];
                sb.append(lit > 0 ? "x" + lit : "¬x" + (-lit));
                if (i < literals.length - 1) sb.append(" ∨ ");
            }
            sb.append(")");
            return sb.toString();
        }
    }

    public static class SatResult {
        public final boolean isSatisfiable;
        public final Map<Integer, Boolean> model; // variable id -> true/false

        public SatResult(boolean isSatisfiable, Map<Integer, Boolean> model) {
            this.isSatisfiable = isSatisfiable;
            this.model = model != null ? model : Collections.emptyMap();
        }

        @Override
        public String toString() {
            if (!isSatisfiable) return "UNSATISFIABLE (No valid port assignment satisfies constraints)";
            StringBuilder sb = new StringBuilder("SATISFIABLE\nModel: ");
            for (Map.Entry<Integer, Boolean> entry : model.entrySet()) {
                sb.append(String.format("x%d=%b ", entry.getKey(), entry.getValue()));
            }
            return sb.toString();
        }
    }

    /**
     * Solves a CNF/3-SAT formula using the recursive DPLL algorithm.
     */
    public static SatResult solve(List<Clause> clauses, int numVariables) {
        Map<Integer, Boolean> assignment = new HashMap<>();
        boolean sat = dpll(clauses, assignment, numVariables);
        return new SatResult(sat, sat ? assignment : null);
    }

    private static boolean dpll(List<Clause> clauses, Map<Integer, Boolean> assignment, int numVariables) {
        // Unit propagation
        while (true) {
            Integer unitLit = findUnitClause(clauses, assignment);
            if (unitLit == null) break;
            int var = Math.abs(unitLit);
            boolean val = unitLit > 0;
            if (assignment.containsKey(var) && assignment.get(var) != val) {
                return false; // Conflict
            }
            assignment.put(var, val);
        }

        // Check if all clauses are satisfied or if any clause is violated
        boolean allSatisfied = true;
        for (Clause c : clauses) {
            int status = evaluateClause(c, assignment);
            if (status == 0) return false; // Violated
            if (status == -1) allSatisfied = false; // Undecided
        }

        if (allSatisfied) {
            // Fill unassigned variables arbitrarily with true
            for (int v = 1; v <= numVariables; v++) {
                assignment.putIfAbsent(v, true);
            }
            return true;
        }

        // Pick unassigned variable
        int nextVar = -1;
        for (int v = 1; v <= numVariables; v++) {
            if (!assignment.containsKey(v)) {
                nextVar = v;
                break;
            }
        }
        if (nextVar == -1) return false;

        // Branch 1: Try true
        Map<Integer, Boolean> branchTrue = new HashMap<>(assignment);
        branchTrue.put(nextVar, true);
        if (dpll(clauses, branchTrue, numVariables)) {
            assignment.putAll(branchTrue);
            return true;
        }

        // Branch 2: Try false
        Map<Integer, Boolean> branchFalse = new HashMap<>(assignment);
        branchFalse.put(nextVar, false);
        if (dpll(clauses, branchFalse, numVariables)) {
            assignment.putAll(branchFalse);
            return true;
        }

        return false;
    }

    private static Integer findUnitClause(List<Clause> clauses, Map<Integer, Boolean> assignment) {
        for (Clause c : clauses) {
            int unassignedLit = 0;
            int unassignedCount = 0;
            boolean clauseSat = false;

            for (int lit : c.literals) {
                int var = Math.abs(lit);
                if (assignment.containsKey(var)) {
                    boolean val = assignment.get(var);
                    if ((lit > 0 && val) || (lit < 0 && !val)) {
                        clauseSat = true;
                        break;
                    }
                } else {
                    unassignedCount++;
                    unassignedLit = lit;
                }
            }

            if (!clauseSat && unassignedCount == 1) {
                return unassignedLit;
            }
        }
        return null;
    }

    /**
     * Evaluates clause: 1 = SAT, 0 = VIOLATED, -1 = UNDECIDED
     */
    private static int evaluateClause(Clause c, Map<Integer, Boolean> assignment) {
        boolean hasUnassigned = false;
        for (int lit : c.literals) {
            int var = Math.abs(lit);
            if (assignment.containsKey(var)) {
                boolean val = assignment.get(var);
                if ((lit > 0 && val) || (lit < 0 && !val)) {
                    return 1; // Satisfied
                }
            } else {
                hasUnassigned = true;
            }
        }
        return hasUnassigned ? -1 : 0;
    }
}
