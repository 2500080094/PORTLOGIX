package com.portlogix.m5_np;

import java.util.*;

/**
 * Module 5 (M5 - CO5): NP-Completeness and Approximation
 * 2-Approximation Algorithm for Minimum Vertex Cover.
 * 
 * PortLogix Use Case:
 * Optimal placement of surveillance scanners and customs inspection checkpoints
 * to monitor all cargo transfer corridors across the port facility.
 * Theoretical Guarantee: Size(Approx) <= 2 * Size(OPT).
 * Time Complexity: O(V + E).
 */
public class VertexCoverApprox {

    public static class ApproxResult {
        public final Set<Integer> approximateCover;
        public final Set<String> matchedEdges;
        public final int approxSize;
        public final Integer exactOptimalSize; // null if too large to compute exactly
        public final double approximationRatio;

        public ApproxResult(Set<Integer> approximateCover, Set<String> matchedEdges, 
                            int approxSize, Integer exactOptimalSize) {
            this.approximateCover = approximateCover;
            this.matchedEdges = matchedEdges;
            this.approxSize = approxSize;
            this.exactOptimalSize = exactOptimalSize;
            this.approximationRatio = (exactOptimalSize != null && exactOptimalSize > 0) 
                    ? (double) approxSize / exactOptimalSize : 1.0;
        }

        @Override
        public String toString() {
            return String.format("Vertex Cover 2-Approx: %d vertices chosen | Exact OPT: %s | Ratio: %.2f (Guaranteed <= 2.0)",
                    approxSize, exactOptimalSize != null ? exactOptimalSize.toString() : "N/A", approximationRatio);
        }
    }

    /**
     * Executes the 2-approximation algorithm using maximal matching.
     */
    public static ApproxResult compute2Approximation(KarpReductions.UndirectedGraph graph) {
        int n = graph.numVertices;
        boolean[] inCover = new boolean[n];
        Set<Integer> cover = new LinkedHashSet<>();
        Set<String> matchedEdges = new LinkedHashSet<>();

        // Iterate through all edges
        for (int u = 0; u < n; u++) {
            if (inCover[u]) continue;
            for (int v = u + 1; v < n; v++) {
                if (graph.hasEdge(u, v) && !inCover[v]) {
                    // Pick edge (u, v), add both endpoints to cover
                    inCover[u] = true;
                    inCover[v] = true;
                    cover.add(u);
                    cover.add(v);
                    matchedEdges.add(String.format("(%s, %s)", graph.labels[u], graph.labels[v]));
                    break;
                }
            }
        }

        // For n <= 22, compute exact minimum vertex cover for empirical verification
        Integer exactOpt = null;
        if (n <= 22) {
            exactOpt = computeExactMinimumVertexCoverSize(graph);
        }

        return new ApproxResult(cover, matchedEdges, cover.size(), exactOpt);
    }

    /**
     * Exact solver via branch-and-bound / subset search for benchmark verification.
     */
    public static int computeExactMinimumVertexCoverSize(KarpReductions.UndirectedGraph graph) {
        int n = graph.numVertices;
        for (int k = 0; k <= n; k++) {
            if (findCoverOfSize(graph, new HashSet<>(), 0, k)) {
                return k;
            }
        }
        return n;
    }

    private static boolean findCoverOfSize(KarpReductions.UndirectedGraph g, Set<Integer> current, int start, int k) {
        if (current.size() == k) {
            return g.isVertexCover(current);
        }
        for (int i = start; i < g.numVertices; i++) {
            current.add(i);
            if (findCoverOfSize(g, current, i + 1, k)) {
                return true;
            }
            current.remove(i);
        }
        return false;
    }
}
