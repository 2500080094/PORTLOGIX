package com.portlogix.m1_strings;

import java.util.ArrayList;
import java.util.List;

/**
 * Module 1 (M1 - CO1): String Algorithms
 * Rabin-Karp Rolling Hash Algorithm.
 * 
 * PortLogix Use Case:
 * Rapidly scanning continuous telemetry and shipment code streams using rolling polynomial hashes.
 * Average Time Complexity: O(n + m), Worst-case: O(n * m). Space: O(1).
 */
public class RabinKarpMatcher {
    private static final long PRIME = 1_000_000_007L;
    private static final int BASE = 256;

    /**
     * Searches for occurrences of pattern in text using polynomial rolling hash.
     * @return List of 0-based start indices.
     */
    public static List<Integer> search(String text, String pattern) {
        List<Integer> matches = new ArrayList<>();
        if (text == null || pattern == null || pattern.isEmpty() || text.length() < pattern.length()) {
            return matches;
        }

        int n = text.length();
        int m = pattern.length();

        // Compute BASE^(m-1) % PRIME
        long h = 1;
        for (int i = 0; i < m - 1; i++) {
            h = (h * BASE) % PRIME;
        }

        long patternHash = 0;
        long textHash = 0;

        for (int i = 0; i < m; i++) {
            patternHash = (patternHash * BASE + pattern.charAt(i)) % PRIME;
            textHash = (textHash * BASE + text.charAt(i)) % PRIME;
        }

        for (int i = 0; i <= n - m; i++) {
            if (patternHash == textHash) {
                // Exact character check to eliminate hash collisions
                boolean match = true;
                for (int j = 0; j < m; j++) {
                    if (text.charAt(i + j) != pattern.charAt(j)) {
                        match = false;
                        break;
                    }
                }
                if (match) {
                    matches.add(i);
                }
            }

            // Calculate rolling hash for next window
            if (i < n - m) {
                textHash = (BASE * (textHash - text.charAt(i) * h) + text.charAt(i + m)) % PRIME;
                if (textHash < 0) {
                    textHash += PRIME;
                }
            }
        }
        return matches;
    }
}
