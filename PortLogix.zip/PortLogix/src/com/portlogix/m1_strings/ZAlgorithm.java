package com.portlogix.m1_strings;

import java.util.ArrayList;
import java.util.List;

/**
 * Module 1 (M1 - CO1): String Algorithms
 * Z-Algorithm (Linear Time String Matching & Periodicity Detection).
 * 
 * PortLogix Use Case:
 * Detect repeated cargo descriptions, identify duplicate declarations, and detect periodic sensor patterns.
 * Time Complexity: O(n + m), Space: O(n + m).
 */
public class ZAlgorithm {

    /**
     * Computes the Z-array for string s.
     * Z[i] is the length of the longest substring starting from s[i] that is also a prefix of s.
     */
    public static int[] computeZArray(String s) {
        if (s == null || s.isEmpty()) return new int[0];
        int n = s.length();
        int[] z = new int[n];
        int l = 0, r = 0;

        for (int i = 1; i < n; i++) {
            if (i <= r) {
                z[i] = Math.min(r - i + 1, z[i - l]);
            }
            while (i + z[i] < n && s.charAt(z[i]) == s.charAt(i + z[i])) {
                z[i]++;
            }
            if (i + z[i] - 1 > r) {
                l = i;
                r = i + z[i] - 1;
            }
        }
        return z;
    }

    /**
     * Pattern search using the Z-algorithm by forming string: pattern + '$' + text.
     * @return List of 0-based indices in text where pattern occurs.
     */
    public static List<Integer> search(String text, String pattern) {
        List<Integer> matches = new ArrayList<>();
        if (text == null || pattern == null || pattern.isEmpty() || text.length() < pattern.length()) {
            return matches;
        }

        String concat = pattern + "\u0001" + text;
        int[] z = computeZArray(concat);
        int m = pattern.length();

        for (int i = m + 1; i < concat.length(); i++) {
            if (z[i] == m) {
                matches.add(i - (m + 1));
            }
        }
        return matches;
    }

    /**
     * Identifies longest repeated substring starting at the beginning (prefix period)
     * to detect redundant descriptions in shipping documentation.
     */
    public static int findSmallestPeriod(String text) {
        if (text == null || text.isEmpty()) return 0;
        int[] z = computeZArray(text);
        int n = text.length();
        for (int i = 1; i < n; i++) {
            if (i + z[i] == n && n % i == 0) {
                return i;
            }
        }
        return n; // text is not periodic
    }
}
