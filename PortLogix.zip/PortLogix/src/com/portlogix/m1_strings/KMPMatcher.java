package com.portlogix.m1_strings;

import java.util.ArrayList;
import java.util.List;

/**
 * Module 1 (M1 - CO1): String Algorithms
 * Knuth-Morris-Pratt (KMP) Algorithm.
 * 
 * PortLogix Use Case:
 * Ultra-fast lookup of exact container serial numbers and ISO prefix IDs in massive cargo log streams.
 * Time Complexity: Preprocessing O(m), Search O(n). Space: O(m).
 */
public class KMPMatcher {

    /**
     * Computes the Prefix Function (pi / failure table) for the pattern.
     * pi[i] is the length of the longest proper prefix of pattern[0..i]
     * that is also a suffix of pattern[0..i].
     */
    public static int[] computePiTable(String pattern) {
        if (pattern == null || pattern.isEmpty()) return new int[0];
        int m = pattern.length();
        int[] pi = new int[m];
        int k = 0;
        for (int i = 1; i < m; i++) {
            while (k > 0 && pattern.charAt(k) != pattern.charAt(i)) {
                k = pi[k - 1];
            }
            if (pattern.charAt(k) == pattern.charAt(i)) {
                k++;
            }
            pi[i] = k;
        }
        return pi;
    }

    /**
     * Searches for all occurrences of pattern in text using KMP.
     * @param text The cargo manifest or container log stream.
     * @param pattern Container identifier or ISO code to search for.
     * @return List of 0-based starting indices where the pattern occurs.
     */
    public static List<Integer> searchAll(String text, String pattern) {
        List<Integer> matches = new ArrayList<>();
        if (text == null || pattern == null || pattern.isEmpty() || text.length() < pattern.length()) {
            return matches;
        }

        int[] pi = computePiTable(pattern);
        int n = text.length();
        int m = pattern.length();
        int q = 0; // number of characters matched

        for (int i = 0; i < n; i++) {
            while (q > 0 && pattern.charAt(q) != text.charAt(i)) {
                q = pi[q - 1];
            }
            if (pattern.charAt(q) == text.charAt(i)) {
                q++;
            }
            if (q == m) {
                matches.add(i - m + 1);
                q = pi[q - 1]; // look for next occurrence
            }
        }
        return matches;
    }

    /**
     * Returns the first index where pattern occurs, or -1 if not found.
     */
    public static int searchFirst(String text, String pattern) {
        List<Integer> occurrences = searchAll(text, pattern);
        return occurrences.isEmpty() ? -1 : occurrences.get(0);
    }
}
