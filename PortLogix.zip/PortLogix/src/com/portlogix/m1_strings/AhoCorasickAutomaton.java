package com.portlogix.m1_strings;

import com.portlogix.model.CargoAlert;

import java.util.*;

/**
 * Module 1 (M1 - CO1): String Algorithms
 * Aho-Corasick Multi-Pattern String Matching Automaton.
 * 
 * PortLogix Use Case:
 * High-speed simultaneous detection of multiple contraband, security alert,
 * and hazardous substance keywords (e.g. "EXPLOSIVE", "CONTRABAND", "RADIOACTIVE", "UN_1993")
 * across live port documentation in O(N + M + Z) time.
 */
public class AhoCorasickAutomaton {

    private static class Node {
        final Map<Character, Node> children = new HashMap<>();
        Node fail;
        final List<String> outputs = new ArrayList<>();
    }

    private final Node root;
    private final Map<String, String> severityMap;

    public AhoCorasickAutomaton() {
        this.root = new Node();
        this.severityMap = new HashMap<>();
    }

    /**
     * Adds a dangerous keyword / alert pattern with associated severity.
     */
    public void addPattern(String pattern, String severity) {
        if (pattern == null || pattern.isEmpty()) return;
        severityMap.put(pattern, severity != null ? severity : "WARNING");
        Node curr = root;
        for (char ch : pattern.toCharArray()) {
            curr = curr.children.computeIfAbsent(ch, c -> new Node());
        }
        curr.outputs.add(pattern);
    }

    /**
     * Builds the failure and dictionary suffix links via BFS.
     */
    public void buildAutomaton() {
        Queue<Node> queue = new ArrayDeque<>();
        root.fail = root;

        // Depth 1 nodes fail to root
        for (Node child : root.children.values()) {
            child.fail = root;
            queue.add(child);
        }

        // BFS to set failure transitions for deeper nodes
        while (!queue.isEmpty()) {
            Node curr = queue.poll();

            for (Map.Entry<Character, Node> entry : curr.children.entrySet()) {
                char ch = entry.getKey();
                Node child = entry.getValue();

                Node f = curr.fail;
                while (f != root && !f.children.containsKey(ch)) {
                    f = f.fail;
                }
                if (f.children.containsKey(ch) && f.children.get(ch) != child) {
                    child.fail = f.children.get(ch);
                } else {
                    child.fail = root;
                }

                // Inherit output patterns from failure node (dictionary suffix link)
                child.outputs.addAll(child.fail.outputs);
                queue.add(child);
            }
        }
    }

    /**
     * Scans the cargo text and returns all detected security alerts.
     */
    public List<CargoAlert> scan(String text) {
        List<CargoAlert> alerts = new ArrayList<>();
        if (text == null || text.isEmpty()) return alerts;

        Node curr = root;
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);

            while (curr != root && !curr.children.containsKey(ch)) {
                curr = curr.fail;
            }

            curr = curr.children.getOrDefault(ch, root);

            if (!curr.outputs.isEmpty()) {
                for (String pattern : curr.outputs) {
                    int startPos = i - pattern.length() + 1;
                    int snippetStart = Math.max(0, startPos - 15);
                    int snippetEnd = Math.min(text.length(), i + 15);
                    String snippet = text.substring(snippetStart, snippetEnd).replace('\n', ' ');
                    String severity = severityMap.getOrDefault(pattern, "WARNING");
                    alerts.add(new CargoAlert(pattern, startPos, severity, snippet));
                }
            }
        }
        return alerts;
    }
}
