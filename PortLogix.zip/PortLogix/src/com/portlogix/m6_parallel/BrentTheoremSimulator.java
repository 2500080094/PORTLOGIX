package com.portlogix.m6_parallel;

import java.util.ArrayList;
import java.util.List;

/**
 * Module 6 (M6 - CO6): Randomized and Parallel Algorithms
 * Brent's Theorem Analyzer and Parallel Task Scheduler.
 * 
 * PortLogix Use Case:
 * Calculating theoretical and practical bounds on parallel cargo processing schedules.
 * Brent's Theorem states that an algorithm with Work W and Depth (Span) D running on
 * p processors achieves execution time bounded by:
 *   T_p <= (W - D) / p + D <= W / p + D
 * 
 * Demonstrates scalability, speedup limits (W / D), and processor saturation curves.
 */
public class BrentTheoremSimulator {

    public static class ProcessorMetric {
        public final int p;
        public final double timeLowerBound; // max(W/p, D)
        public final double timeUpperBound; // (W - D)/p + D
        public final double speedup;        // W / timeUpperBound
        public final double efficiency;     // speedup / p

        public ProcessorMetric(int p, double timeLowerBound, double timeUpperBound, double speedup, double efficiency) {
            this.p = p;
            this.timeLowerBound = timeLowerBound;
            this.timeUpperBound = timeUpperBound;
            this.speedup = speedup;
            this.efficiency = efficiency;
        }

        @Override
        public String toString() {
            return String.format("p=%2d processors | Time Bound: [%.1f, %.1f] | Speedup: %5.2fx | Efficiency: %5.1f%%",
                    p, timeLowerBound, timeUpperBound, speedup, efficiency * 100.0);
        }
    }

    public static class ScheduleAnalysis {
        public final long totalWorkW;
        public final long criticalDepthD;
        public final double maxTheoreticalSpeedup; // W / D
        public final int optimalProcessorCount;
        public final List<ProcessorMetric> processorMetrics;

        public ScheduleAnalysis(long totalWorkW, long criticalDepthD, double maxTheoreticalSpeedup,
                                int optimalProcessorCount, List<ProcessorMetric> processorMetrics) {
            this.totalWorkW = totalWorkW;
            this.criticalDepthD = criticalDepthD;
            this.maxTheoreticalSpeedup = maxTheoreticalSpeedup;
            this.optimalProcessorCount = optimalProcessorCount;
            this.processorMetrics = processorMetrics;
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(String.format("Brent's Theorem Analysis (Work W=%d ops, Depth D=%d steps):\n", totalWorkW, criticalDepthD));
            sb.append(String.format("  -> Max Theoretical Speedup (W/D): %.2fx\n", maxTheoreticalSpeedup));
            sb.append(String.format("  -> Recommended Processor Count (>=80%% eff): %d processors\n", optimalProcessorCount));
            for (ProcessorMetric pm : processorMetrics) {
                sb.append("  " + pm.toString() + "\n");
            }
            return sb.toString();
        }
    }

    /**
     * Evaluates Brent's theorem bounds across various processor allocations.
     * @param work Total operations (e.g. 100,000 container inspections)
     * @param depth Critical path length (e.g. 50 sequential pipeline stages)
     */
    public static ScheduleAnalysis analyze(long work, long depth) {
        if (depth <= 0) depth = 1;
        if (work < depth) work = depth;

        double maxSpeedup = (double) work / depth;
        List<ProcessorMetric> metrics = new ArrayList<>();
        int[] testProcessors = {1, 2, 4, 8, 16, 32, 64, 128};
        int recommendedP = 1;

        for (int p : testProcessors) {
            double lowerBound = Math.max((double) work / p, (double) depth);
            double upperBound = ((double) (work - depth) / p) + depth;
            double speedup = (double) work / upperBound;
            double efficiency = speedup / p;

            metrics.add(new ProcessorMetric(p, lowerBound, upperBound, speedup, efficiency));

            if (efficiency >= 0.80) {
                recommendedP = p;
            }
        }

        return new ScheduleAnalysis(work, depth, maxSpeedup, recommendedP, metrics);
    }
}
