package com.portlogix.m6_parallel;

import com.portlogix.model.Container;

import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

/**
 * Module 6 (M6 - CO6): Randomized and Parallel Algorithms
 * ForkJoin Parallel Reduction for Port Data Aggregation.
 * 
 * PortLogix Use Case:
 * High-throughput parallel aggregation of port-wide metrics:
 * Total container weight (MT), peak dwell times, and average priority scores.
 * Work: O(N), Span: O(log N).
 */
public class ParallelReduce {

    private static final int THRESHOLD = 500;
    private static final ForkJoinPool POOL = new ForkJoinPool();

    public static class AggregateStats {
        public final double totalWeightMt;
        public final int maxDwellHours;
        public final double avgPriority;
        public final int containerCount;
        public final long parallelElapsedNanos;
        public final long sequentialElapsedNanos;

        public AggregateStats(double totalWeightMt, int maxDwellHours, double avgPriority, int containerCount,
                              long parallelElapsedNanos, long sequentialElapsedNanos) {
            this.totalWeightMt = totalWeightMt;
            this.maxDwellHours = maxDwellHours;
            this.avgPriority = avgPriority;
            this.containerCount = containerCount;
            this.parallelElapsedNanos = parallelElapsedNanos;
            this.sequentialElapsedNanos = sequentialElapsedNanos;
        }

        public double getSpeedup() {
            if (parallelElapsedNanos == 0) return 1.0;
            return (double) sequentialElapsedNanos / parallelElapsedNanos;
        }

        @Override
        public String toString() {
            return String.format("Aggregated %d containers | Weight: %.2f MT | Max Dwell: %dh | Avg Prio: %.1f | Speedup: %.2fx",
                    containerCount, totalWeightMt, maxDwellHours, avgPriority, getSpeedup());
        }
    }

    private static class PartialResult {
        double weight;
        int maxDwell;
        long prioritySum;
        int count;

        PartialResult(double weight, int maxDwell, long prioritySum, int count) {
            this.weight = weight;
            this.maxDwell = maxDwell;
            this.prioritySum = prioritySum;
            this.count = count;
        }

        static PartialResult combine(PartialResult a, PartialResult b) {
            return new PartialResult(
                    a.weight + b.weight,
                    Math.max(a.maxDwell, b.maxDwell),
                    a.prioritySum + b.prioritySum,
                    a.count + b.count
            );
        }
    }

    private static class ReduceTask extends RecursiveTask<PartialResult> {
        private final List<Container> list;
        private final int start;
        private final int end;

        ReduceTask(List<Container> list, int start, int end) {
            this.list = list;
            this.start = start;
            this.end = end;
        }

        @Override
        protected PartialResult compute() {
            if (end - start <= THRESHOLD) {
                double w = 0;
                int maxD = 0;
                long pSum = 0;
                for (int i = start; i < end; i++) {
                    Container c = list.get(i);
                    w += c.getWeightMt();
                    if (c.getDwellHours() > maxD) maxD = c.getDwellHours();
                    pSum += c.getPriorityScore();
                }
                return new PartialResult(w, maxD, pSum, end - start);
            }

            int mid = (start + end) >>> 1;
            ReduceTask left = new ReduceTask(list, start, mid);
            ReduceTask right = new ReduceTask(list, mid, end);
            left.fork();
            PartialResult rightRes = right.compute();
            PartialResult leftRes = left.join();
            return PartialResult.combine(leftRes, rightRes);
        }
    }

    /**
     * Executes parallel reduction and compares with sequential baseline.
     */
    public static AggregateStats aggregate(List<Container> containers) {
        if (containers == null || containers.isEmpty()) {
            return new AggregateStats(0, 0, 0, 0, 0, 0);
        }

        // Sequential benchmark
        long seqStart = System.nanoTime();
        double seqW = 0;
        int seqMaxD = 0;
        long seqPSum = 0;
        for (Container c : containers) {
            seqW += c.getWeightMt();
            if (c.getDwellHours() > seqMaxD) seqMaxD = c.getDwellHours();
            seqPSum += c.getPriorityScore();
        }
        long seqElapsed = System.nanoTime() - seqStart;

        // Parallel ForkJoin execution
        long parStart = System.nanoTime();
        PartialResult res = POOL.invoke(new ReduceTask(containers, 0, containers.size()));
        long parElapsed = System.nanoTime() - parStart;

        double avgPrio = res.count > 0 ? (double) res.prioritySum / res.count : 0;
        return new AggregateStats(res.weight, res.maxDwell, avgPrio, res.count, parElapsed, seqElapsed);
    }
}
