package com.portlogix.m6_parallel;

import java.util.Arrays;

/**
 * Module 6 (M6 - CO6): Randomized and Parallel Algorithms
 * Blelloch Parallel Prefix Scan Algorithm.
 * 
 * PortLogix Use Case:
 * Computing cumulative cargo tonnage, running berth occupancy statistics,
 * and linear crane loading schedules in parallel with optimal work-efficiency.
 * Work: O(N) operations (Work-efficient).
 * Depth / Span: O(log N) parallel steps.
 */
public class BlellochScan {

    public static class ScanResult {
        public final double[] exclusiveScan;
        public final double[] inclusiveScan;
        public final double totalSum;
        public final int originalSize;
        public final int paddedSize;
        public final int treeDepth;

        public ScanResult(double[] exclusiveScan, double[] inclusiveScan, double totalSum, 
                          int originalSize, int paddedSize, int treeDepth) {
            this.exclusiveScan = exclusiveScan;
            this.inclusiveScan = inclusiveScan;
            this.totalSum = totalSum;
            this.originalSize = originalSize;
            this.paddedSize = paddedSize;
            this.treeDepth = treeDepth;
        }

        @Override
        public String toString() {
            return String.format("Blelloch Scan: Total Sum = %.2f across %d elements (Depth = %d)",
                    totalSum, originalSize, treeDepth);
        }
    }

    /**
     * Executes the Blelloch work-efficient parallel scan.
     * @param input Raw array of cargo metric values (e.g., container weights in MT)
     * @return ScanResult with exclusive and inclusive prefix sums
     */
    public static ScanResult computeScan(double[] input) {
        if (input == null || input.length == 0) {
            return new ScanResult(new double[0], new double[0], 0.0, 0, 0, 0);
        }

        int n = input.length;
        // Pad to next power of 2
        int m = 1;
        int depth = 0;
        while (m < n) {
            m <<= 1;
            depth++;
        }

        double[] a = new double[m];
        System.arraycopy(input, 0, a, 0, n);

        // Phase 1: Up-Sweep (Parallel Reduce)
        for (int d = 0; d < depth; d++) {
            int step = 1 << (d + 1);
            int half = 1 << d;
            for (int i = 0; i < m; i += step) {
                a[i + step - 1] += a[i + half - 1];
            }
        }

        double totalSum = a[m - 1];
        a[m - 1] = 0; // Set root to zero for exclusive scan

        // Phase 2: Down-Sweep
        for (int d = depth - 1; d >= 0; d--) {
            int step = 1 << (d + 1);
            int half = 1 << d;
            for (int i = 0; i < m; i += step) {
                double t = a[i + half - 1];
                a[i + half - 1] = a[i + step - 1];
                a[i + step - 1] += t;
            }
        }

        double[] exclusive = Arrays.copyOf(a, n);
        double[] inclusive = new double[n];
        for (int i = 0; i < n; i++) {
            inclusive[i] = exclusive[i] + input[i];
        }

        return new ScanResult(exclusive, inclusive, totalSum, n, m, depth);
    }
}
