package com.portlogix.m6_parallel;

import com.portlogix.model.Container;

import java.util.Comparator;
import java.util.List;
import java.util.Random;

/**
 * Module 6 (M6 - CO6): Randomized and Parallel Algorithms
 * Randomized QuickSort with 3-Way Partitioning.
 * 
 * PortLogix Use Case:
 * High-speed sorting and ranking of massive cargo container records by priority,
 * dwell time, or weight. Randomized pivot prevents adversarial/worst-case O(N^2)
 * latency degradations on presorted manifests.
 * Expected Time Complexity: O(N log N), Space: O(log N).
 */
public class RandomizedQuickSort {
    private static final Random RNG = new Random();

    public static class SortStats {
        public long comparisons = 0;
        public long swaps = 0;
        public long timeNanos = 0;
    }

    /**
     * Sorts a list of containers using Randomized 3-way QuickSort.
     */
    public static SortStats sortContainers(List<Container> list, Comparator<Container> comparator) {
        SortStats stats = new SortStats();
        long start = System.nanoTime();
        if (list != null && list.size() > 1) {
            quickSort(list, 0, list.size() - 1, comparator, stats);
        }
        stats.timeNanos = System.nanoTime() - start;
        return stats;
    }

    private static void quickSort(List<Container> list, int low, int high, 
                                  Comparator<Container> comp, SortStats stats) {
        if (low >= high) return;

        // Randomized pivot selection
        int randomIndex = low + RNG.nextInt(high - low + 1);
        swap(list, low, randomIndex, stats);

        Container pivot = list.get(low);
        int lt = low;      // list[low..lt-1] < pivot
        int gt = high;     // list[gt+1..high] > pivot
        int i = low + 1;   // list[lt..i-1] == pivot

        while (i <= gt) {
            stats.comparisons++;
            int cmp = comp.compare(list.get(i), pivot);
            if (cmp < 0) {
                swap(list, lt++, i++, stats);
            } else if (cmp > 0) {
                swap(list, i, gt--, stats);
            } else {
                i++;
            }
        }

        quickSort(list, low, lt - 1, comp, stats);
        quickSort(list, gt + 1, high, comp, stats);
    }

    private static void swap(List<Container> list, int i, int j, SortStats stats) {
        if (i != j) {
            Container temp = list.get(i);
            list.set(i, list.get(j));
            list.set(j, temp);
            stats.swaps++;
        }
    }
}
