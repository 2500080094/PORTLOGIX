package com.portlogix.m6_parallel;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Module 6 (M6 - CO6): Randomized and Parallel Algorithms
 * Reservoir Sampling (Algorithm R).
 * 
 * PortLogix Use Case:
 * Uniform unbiased random sampling from continuous, unbounded streams of port events,
 * RFID container sensor pings, and vessel AIS tracking updates without storing the full history.
 * Space: Strictly O(K) where K is sample size.
 */
public class ReservoirSampler<T> {
    private final int k;
    private final List<T> reservoir;
    private long itemsSeen;
    private final Random rng;

    public ReservoirSampler(int k) {
        if (k <= 0) throw new IllegalArgumentException("Sample size k must be positive: " + k);
        this.k = k;
        this.reservoir = new ArrayList<>(k);
        this.itemsSeen = 0;
        this.rng = new Random();
    }

    /**
     * Processes a single streaming event item online.
     */
    public void processItem(T item) {
        itemsSeen++;
        if (reservoir.size() < k) {
            reservoir.add(item);
        } else {
            // Pick a random index between 0 and itemsSeen - 1
            long j = (long) (rng.nextDouble() * itemsSeen);
            if (j < k) {
                reservoir.set((int) j, item);
            }
        }
    }

    /**
     * Processes an iterator of items.
     */
    public List<T> sampleFromIterator(Iterator<T> stream) {
        while (stream.hasNext()) {
            processItem(stream.next());
        }
        return getSample();
    }

    public List<T> getSample() {
        return new ArrayList<>(reservoir);
    }

    public long getItemsSeen() {
        return itemsSeen;
    }

    public int getSampleSize() {
        return reservoir.size();
    }

    public double getInclusionProbability() {
        if (itemsSeen == 0) return 0.0;
        return Math.min(1.0, (double) k / itemsSeen);
    }
}
