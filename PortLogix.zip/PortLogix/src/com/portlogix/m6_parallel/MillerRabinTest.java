package com.portlogix.m6_parallel;

import java.math.BigInteger;
import java.util.Random;

/**
 * Module 6 (M6 - CO6): Randomized and Parallel Algorithms
 * Miller-Rabin Primality Test.
 * 
 * PortLogix Use Case:
 * Cryptographic manifest authentication, verifying digital tamper-evident seals on container bills,
 * and generating secure large prime modulus parameters for port telemetry hashing.
 * Error probability after k rounds: <= 4^(-k).
 */
public class MillerRabinTest {
    private static final Random RNG = new Random();

    public static class PrimalityResult {
        public final boolean isProbablyPrime;
        public final int roundsTested;
        public final double confidencePercentage;

        public PrimalityResult(boolean isProbablyPrime, int roundsTested) {
            this.isProbablyPrime = isProbablyPrime;
            this.roundsTested = roundsTested;
            this.confidencePercentage = isProbablyPrime 
                    ? (1.0 - Math.pow(0.25, roundsTested)) * 100.0 
                    : 100.0;
        }

        @Override
        public String toString() {
            return String.format("%s (Confidence: %.6f%% after %d rounds)",
                    isProbablyPrime ? "PROBABLY PRIME" : "COMPOSITE",
                    confidencePercentage, roundsTested);
        }
    }

    /**
     * Miller-Rabin test for BigInteger.
     */
    public static PrimalityResult testPrime(BigInteger n, int k) {
        if (n.compareTo(BigInteger.TWO) < 0) return new PrimalityResult(false, 0);
        if (n.equals(BigInteger.TWO) || n.equals(BigInteger.valueOf(3))) return new PrimalityResult(true, k);
        if (n.mod(BigInteger.TWO).equals(BigInteger.ZERO)) return new PrimalityResult(false, 1);

        // Write n - 1 as 2^s * d
        BigInteger d = n.subtract(BigInteger.ONE);
        int s = 0;
        while (d.mod(BigInteger.TWO).equals(BigInteger.ZERO)) {
            d = d.divide(BigInteger.TWO);
            s++;
        }

        BigInteger nMinusOne = n.subtract(BigInteger.ONE);
        BigInteger nMinusThree = n.subtract(BigInteger.valueOf(3));

        for (int round = 0; round < k; round++) {
            BigInteger a;
            do {
                a = new BigInteger(n.bitLength(), RNG);
            } while (a.compareTo(BigInteger.TWO) < 0 || a.compareTo(nMinusOne) >= 0);

            BigInteger x = a.modPow(d, n);
            if (x.equals(BigInteger.ONE) || x.equals(nMinusOne)) {
                continue;
            }

            boolean composite = true;
            for (int r = 1; r < s; r++) {
                x = x.modPow(BigInteger.TWO, n);
                if (x.equals(nMinusOne)) {
                    composite = false;
                    break;
                }
            }

            if (composite) {
                return new PrimalityResult(false, round + 1);
            }
        }

        return new PrimalityResult(true, k);
    }

    /**
     * Fast Miller-Rabin for primitive 64-bit long.
     */
    public static boolean isPrime(long n, int k) {
        if (n < 2) return false;
        if (n == 2 || n == 3) return true;
        if ((n & 1) == 0) return false;

        long d = n - 1;
        int s = 0;
        while ((d & 1) == 0) {
            d >>= 1;
            s++;
        }

        for (int i = 0; i < k; i++) {
            long a = 2 + (long) (RNG.nextDouble() * (n - 3));
            long x = modPow(a, d, n);

            if (x == 1 || x == n - 1) continue;

            boolean comp = true;
            for (int r = 1; r < s; r++) {
                x = mulMod(x, x, n);
                if (x == n - 1) {
                    comp = false;
                    break;
                }
            }
            if (comp) return false;
        }
        return true;
    }

    private static long mulMod(long a, long b, long mod) {
        return BigInteger.valueOf(a).multiply(BigInteger.valueOf(b)).mod(BigInteger.valueOf(mod)).longValue();
    }

    private static long modPow(long base, long exp, long mod) {
        long res = 1;
        base %= mod;
        while (exp > 0) {
            if ((exp & 1) == 1) res = mulMod(res, base, mod);
            base = mulMod(base, base, mod);
            exp >>= 1;
        }
        return res;
    }
}
