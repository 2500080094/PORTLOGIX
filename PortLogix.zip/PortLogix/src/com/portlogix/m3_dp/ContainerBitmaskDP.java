package com.portlogix.m3_dp;

import com.portlogix.model.Container;

import java.util.ArrayList;
import java.util.List;

/**
 * Module 3 (M3 - CO3): Advanced Dynamic Programming
 * Bitmask Dynamic Programming for Constrained Container Selection.
 * 
 * PortLogix Use Case:
 * Optimal container batch selection for Automated Guided Vehicles (AGVs) or specialized
 * berth bays under strict mutual safety conflict rules (e.g. explosive & flammable segregation)
 * and maximum payload limits.
 * Complexity: O(2^n * n), feasible for n <= 20.
 */
public class ContainerBitmaskDP {

    public static class SelectionResult {
        public final int maxPriority;
        public final double totalWeight;
        public final List<Container> selectedContainers;

        public SelectionResult(int maxPriority, double totalWeight, List<Container> selectedContainers) {
            this.maxPriority = maxPriority;
            this.totalWeight = totalWeight;
            this.selectedContainers = selectedContainers;
        }

        @Override
        public String toString() {
            return String.format("Optimal Selection [Total Priority: %d, Total Weight: %.2f MT, Containers: %d]",
                    maxPriority, totalWeight, selectedContainers.size());
        }
    }

    /**
     * Solves the constrained container selection using Bitmask DP.
     * @param containers Candidate container pool (N <= 20)
     * @param maxWeightMt Maximum capacity of the transfer platform / AGV
     * @param conflictMatrix Boolean matrix where conflictMatrix[i][j] == true means containers i and j cannot be co-loaded
     */
    public static SelectionResult optimizeSelection(List<Container> containers, double maxWeightMt, boolean[][] conflictMatrix) {
        int n = Math.min(containers.size(), 20); // Cap at 20 for 2^20 states
        int numStates = 1 << n;

        // dp[mask] = max priority achievable with the subset 'mask'
        int[] dp = new int[numStates];
        double[] weight = new double[numStates];
        boolean[] isValid = new boolean[numStates];

        isValid[0] = true;
        dp[0] = 0;
        weight[0] = 0.0;

        int bestMask = 0;
        int maxPriority = 0;

        // Precompute single container weights and priorities
        for (int mask = 1; mask < numStates; mask++) {
            // Find lowest set bit
            int lsb = Integer.numberOfTrailingZeros(mask);
            int prevMask = mask ^ (1 << lsb);

            if (!isValid[prevMask]) {
                isValid[mask] = false;
                continue;
            }

            // Check conflicts between container 'lsb' and any already in prevMask
            boolean conflict = false;
            for (int j = 0; j < n; j++) {
                if ((prevMask & (1 << j)) != 0 && conflictMatrix != null && conflictMatrix[lsb][j]) {
                    conflict = true;
                    break;
                }
            }

            if (conflict) {
                isValid[mask] = false;
                continue;
            }

            double newWeight = weight[prevMask] + containers.get(lsb).getWeightMt();
            if (newWeight > maxWeightMt) {
                isValid[mask] = false;
                continue;
            }

            isValid[mask] = true;
            weight[mask] = newWeight;
            dp[mask] = dp[prevMask] + containers.get(lsb).getPriorityScore();

            if (dp[mask] > maxPriority) {
                maxPriority = dp[mask];
                bestMask = mask;
            }
        }

        List<Container> selected = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if ((bestMask & (1 << i)) != 0) {
                selected.add(containers.get(i));
            }
        }

        return new SelectionResult(maxPriority, weight[bestMask], selected);
    }
}
