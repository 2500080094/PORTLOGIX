package com.portlogix.m3_dp;

/**
 * Module 3 (M3 - CO3): Advanced Dynamic Programming
 * Matrix-Chain Multiplication (MCM) Optimization.
 * 
 * PortLogix Use Case:
 * Optimizing complex multi-table relational join pipelines across port telemetry databases
 * (e.g. Vessels -> Manifests -> Containers -> InspectionLogs -> GatePasses)
 * by finding the optimal evaluation tree that minimizes intermediate record computations.
 * Complexity: O(N^3) Time, O(N^2) Space.
 */
public class MatrixChainOptimizer {

    public static class MCMResult {
        public final long minOperations;
        public final long naiveOperations;
        public final String optimalParenthesization;
        public final int[][] dpTable;
        public final int[][] splitTable;

        public MCMResult(long minOperations, long naiveOperations, String optimalParenthesization, 
                         int[][] dpTable, int[][] splitTable) {
            this.minOperations = minOperations;
            this.naiveOperations = naiveOperations;
            this.optimalParenthesization = optimalParenthesization;
            this.dpTable = dpTable;
            this.splitTable = splitTable;
        }

        public double getOptimizationPercentage() {
            if (naiveOperations == 0) return 0.0;
            return ((double) (naiveOperations - minOperations) / naiveOperations) * 100.0;
        }

        @Override
        public String toString() {
            return String.format("MCM Order: %s | Cost: %d ops (Naive: %d ops, Saved: %.1f%%)",
                    optimalParenthesization, minOperations, naiveOperations, getOptimizationPercentage());
        }
    }

    /**
     * Finds the optimal order to join/multiply chain of matrices with dimensions p[0..n].
     * Matrix i has dimension p[i-1] x p[i].
     * @param p Array of dimensions of length n + 1 (for n matrices)
     * @param tableNames Optional names of tables/operations (e.g., ["Vessels", "Manifests", "Containers", ...])
     */
    public static MCMResult optimize(int[] p, String[] tableNames) {
        int n = p.length - 1; // Number of matrices
        int[][] m = new int[n + 1][n + 1];
        int[][] s = new int[n + 1][n + 1];

        // Length of sub-chain
        for (int l = 2; l <= n; l++) {
            for (int i = 1; i <= n - l + 1; i++) {
                int j = i + l - 1;
                m[i][j] = Integer.MAX_VALUE;
                for (int k = i; k <= j - 1; k++) {
                    long cost = (long) m[i][k] + m[k + 1][j] + (long) p[i - 1] * p[k] * p[j];
                    if (cost < m[i][j]) {
                        m[i][j] = (int) cost;
                        s[i][j] = k;
                    }
                }
            }
        }

        // Calculate naive left-to-right join cost
        long naive = 0;
        long currentRows = p[0];
        for (int i = 1; i < n; i++) {
            naive += currentRows * p[i] * p[i + 1];
            // Result dimension is p[0] x p[i+1]
        }

        String optimalOrder = reconstructOrder(s, 1, n, tableNames);
        return new MCMResult(m[1][n], naive, optimalOrder, m, s);
    }

    private static String reconstructOrder(int[][] s, int i, int j, String[] names) {
        if (i == j) {
            return (names != null && i - 1 < names.length) ? names[i - 1] : "T" + i;
        }
        return "(" + reconstructOrder(s, i, s[i][j], names) + " ⋈ " +
                     reconstructOrder(s, s[i][j] + 1, j, names) + ")";
    }
}
