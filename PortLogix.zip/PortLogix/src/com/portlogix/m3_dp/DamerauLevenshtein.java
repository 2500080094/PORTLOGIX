package com.portlogix.m3_dp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Module 3 (M3 - CO3): Advanced Dynamic Programming
 * Damerau-Levenshtein Distance Algorithm.
 * 
 * PortLogix Use Case:
 * Correcting Optical Character Recognition (OCR) errors on weather-worn container placards,
 * mistyped ISO container codes, and vessel names. Supports insertions, deletions,
 * substitutions, and adjacent character transpositions.
 * Time Complexity: O(|s1| * |s2|), Space: O(|s1| * |s2|).
 */
public class DamerauLevenshtein {

    /**
     * Calculates the true Damerau-Levenshtein distance (allowing arbitrary transpositions).
     */
    public static int computeDistance(String s1, String s2) {
        if (s1 == null) s1 = "";
        if (s2 == null) s2 = "";
        int len1 = s1.length();
        int len2 = s2.length();

        int maxDist = len1 + len2;
        Map<Character, Integer> lastSeen = new HashMap<>();

        int[][] dp = new int[len1 + 2][len2 + 2];
        dp[0][0] = maxDist;
        for (int i = 0; i <= len1; i++) {
            dp[i + 1][0] = maxDist;
            dp[i + 1][1] = i;
        }
        for (int j = 0; j <= len2; j++) {
            dp[0][j + 1] = maxDist;
            dp[1][j + 1] = j;
        }

        for (int i = 1; i <= len1; i++) {
            int db = 0;
            char c1 = s1.charAt(i - 1);
            for (int j = 1; j <= len2; j++) {
                char c2 = s2.charAt(j - 1);
                int k = lastSeen.getOrDefault(c2, 0);
                int l = db;

                int cost = (c1 == c2) ? 0 : 1;
                if (cost == 0) db = j;

                int deletion = dp[i][j + 1] + 1;
                int insertion = dp[i + 1][j] + 1;
                int substitution = dp[i][j] + cost;
                int transposition = dp[k][l] + (i - k - 1) + 1 + (j - l - 1);

                dp[i + 1][j + 1] = Math.min(Math.min(deletion, insertion),
                                           Math.min(substitution, transposition));
            }
            lastSeen.put(c1, i);
        }

        return dp[len1 + 1][len2 + 1];
    }

    public static class MatchResult {
        public final String target;
        public final int distance;
        public final double similarityScore; // 0.0 to 1.0

        public MatchResult(String target, int distance, double similarityScore) {
            this.target = target;
            this.distance = distance;
            this.similarityScore = similarityScore;
        }

        @Override
        public String toString() {
            return String.format("%s (Distance: %d, Match: %.1f%%)", target, distance, similarityScore * 100);
        }
    }

    /**
     * Finds the closest valid container ID from a registered fleet dictionary.
     */
    public static MatchResult findBestMatch(String query, List<String> candidates) {
        if (candidates == null || candidates.isEmpty()) return null;

        String bestTarget = candidates.get(0);
        int bestDist = Integer.MAX_VALUE;

        for (String candidate : candidates) {
            int dist = computeDistance(query, candidate);
            if (dist < bestDist) {
                bestDist = dist;
                bestTarget = candidate;
            }
        }

        int maxLen = Math.max(query.length(), bestTarget.length());
        double score = (maxLen == 0) ? 1.0 : 1.0 - ((double) bestDist / maxLen);
        return new MatchResult(bestTarget, bestDist, Math.max(0.0, score));
    }
}
