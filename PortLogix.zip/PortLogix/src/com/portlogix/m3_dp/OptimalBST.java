package com.portlogix.m3_dp;

/**
 * Module 3 (M3 - CO3): Advanced Dynamic Programming
 * Optimal Binary Search Tree (OBST).
 * 
 * PortLogix Use Case:
 * Minimizing the expected latency and disk I/O when looking up frequently accessed cargo categories,
 * customs tariff codes, and container registries at high-traffic gate portals.
 * Complexity: O(N^3) Time, O(N^2) Space.
 */
public class OptimalBST {

    public static class OBSTResult {
        public final double minExpectedCost;
        public final int[][] rootTable;
        public final double[][] eTable;
        public final double[][] wTable;
        public final String[] keys;

        public OBSTResult(double minExpectedCost, int[][] rootTable, double[][] eTable, double[][] wTable, String[] keys) {
            this.minExpectedCost = minExpectedCost;
            this.rootTable = rootTable;
            this.eTable = eTable;
            this.wTable = wTable;
            this.keys = keys;
        }

        public String formatTree() {
            int n = keys.length;
            StringBuilder sb = new StringBuilder();
            printSubtree(1, n, 0, "ROOT", rootTable, keys, sb);
            return sb.toString();
        }

        private void printSubtree(int i, int j, int depth, String side, int[][] root, String[] k, StringBuilder sb) {
            if (i > j) return;
            int r = root[i][j];
            String indent = "  ".repeat(depth);
            sb.append(String.format("%s[%s] Key: '%s' (Index %d)\n", indent, side, k[r - 1], r));
            printSubtree(i, r - 1, depth + 1, "LEFT", root, k, sb);
            printSubtree(r + 1, j, depth + 1, "RIGHT", root, k, sb);
        }
    }

    /**
     * Constructs the Optimal BST.
     * @param keys Sorted list of cargo category / container lookup keys
     * @param p Probabilities of successful searches for keys (length n)
     * @param q Probabilities of unsuccessful searches in intervals (length n + 1)
     */
    public static OBSTResult buildOptimalBST(String[] keys, double[] p, double[] q) {
        int n = keys.length;
        double[][] e = new double[n + 2][n + 2];
        double[][] w = new double[n + 2][n + 2];
        int[][] root = new int[n + 2][n + 2];

        for (int i = 1; i <= n + 1; i++) {
            e[i][i - 1] = q[i - 1];
            w[i][i - 1] = q[i - 1];
        }

        for (int l = 1; l <= n; l++) {
            for (int i = 1; i <= n - l + 1; i++) {
                int j = i + l - 1;
                e[i][j] = Double.POSITIVE_INFINITY;
                w[i][j] = w[i][j - 1] + p[j - 1] + q[j];

                for (int r = i; r <= j; r++) {
                    double t = e[i][r - 1] + e[r + 1][j] + w[i][j];
                    if (t < e[i][j]) {
                        e[i][j] = t;
                        root[i][j] = r;
                    }
                }
            }
        }

        return new OBSTResult(e[1][n], root, e, w, keys);
    }
}
