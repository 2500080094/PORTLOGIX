package com.portlogix.m4_flow;

/**
 * Module 4 (M4 - CO4): Network Flow
 * Ford-Fulkerson Algorithm (DFS-based Augmenting Path).
 * 
 * PortLogix Use Case:
 * Modeling baseline cargo flow and verifying capacity bounds across port transshipment routes.
 */
public class FordFulkerson {

    public static double computeMaxFlow(FlowNetwork network, int source, int sink) {
        network.resetAllFlows();
        double maxFlow = 0.0;
        int n = network.getNumVertices();

        while (true) {
            boolean[] visited = new boolean[n];
            FlowEdge[] edgeTo = new FlowEdge[n];

            if (!dfs(network, source, sink, visited, edgeTo)) {
                break; // No more augmenting paths
            }

            // Find bottleneck capacity along path
            double bottle = Double.POSITIVE_INFINITY;
            for (int v = sink; v != source; v = edgeTo[v].getFrom()) {
                bottle = Math.min(bottle, edgeTo[v].getResidualCapacity());
            }

            // Augment flow
            for (int v = sink; v != source; v = edgeTo[v].getFrom()) {
                edgeTo[v].addResidualFlow(bottle);
            }

            maxFlow += bottle;
        }

        return maxFlow;
    }

    private static boolean dfs(FlowNetwork network, int v, int sink, boolean[] visited, FlowEdge[] edgeTo) {
        visited[v] = true;
        if (v == sink) return true;

        for (FlowEdge e : network.getAdj(v)) {
            int w = e.getTo();
            if (!visited[w] && e.getResidualCapacity() > 1e-9) {
                edgeTo[w] = e;
                if (dfs(network, w, sink, visited, edgeTo)) {
                    return true;
                }
            }
        }
        return false;
    }
}
