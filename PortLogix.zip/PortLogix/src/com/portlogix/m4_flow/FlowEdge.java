package com.portlogix.m4_flow;

/**
 * Represents a directed edge in the PortLogix cargo flow network with residual tracking.
 */
public class FlowEdge {
    private final int from;
    private final int to;
    private final double capacity;
    private double flow;
    private FlowEdge residual;

    public FlowEdge(int from, int to, double capacity) {
        this.from = from;
        this.to = to;
        this.capacity = capacity;
        this.flow = 0.0;
    }

    public int getFrom() { return from; }
    public int getTo() { return to; }
    public double getCapacity() { return capacity; }
    public double getFlow() { return flow; }
    public FlowEdge getResidual() { return residual; }
    public void setResidual(FlowEdge residual) { this.residual = residual; }

    /**
     * Residual capacity of this directed edge.
     */
    public double getResidualCapacity() {
        return capacity - flow;
    }

    /**
     * Augments flow along this edge by delta and decreases residual back-edge flow by delta.
     */
    public void addResidualFlow(double delta) {
        this.flow += delta;
        if (residual != null) {
            residual.flow -= delta;
        }
    }

    public void resetFlow() {
        this.flow = 0.0;
    }

    @Override
    public String toString() {
        return String.format("%d -> %d (Flow: %.1f / Cap: %.1f)", from, to, flow, capacity);
    }
}
