package com.portlogix.m4_flow;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

/**
 * Module 4 (M4 - CO4): Network Flow
 * Minimum Cut Analyzer (Max-Flow Min-Cut Theorem).
 * 
 * PortLogix Use Case:
 * Identifying critical infrastructural bottlenecks and vulnerabilities in port cargo transfers.
 * Edges crossing the S-T cut represent the maximum-impact expansion points.
 */
public class MinCutAnalyzer {

    public static class MinCutResult {
        public final double cutCapacity;
        public final List<Integer> sourcePartition;
        public final List<Integer> sinkPartition;
        public final List<FlowEdge> criticalBottleneckEdges;

        public MinCutResult(double cutCapacity, List<Integer> sourcePartition, List<Integer> sinkPartition,
                            List<FlowEdge> criticalBottleneckEdges) {
            this.cutCapacity = cutCapacity;
            this.sourcePartition = sourcePartition;
            this.sinkPartition = sinkPartition;
            this.criticalBottleneckEdges = criticalBottleneckEdges;
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(String.format("Min-Cut Capacity: %.2f TEU/h | Bottlenecks: %d edges\n",
                    cutCapacity, criticalBottleneckEdges.size()));
            for (FlowEdge e : criticalBottleneckEdges) {
                sb.append(String.format("  -> Critical Bottleneck: Node %d -> Node %d (Cap: %.1f)\n",
                        e.getFrom(), e.getTo(), e.getCapacity()));
            }
            return sb.toString();
        }
    }

    /**
     * Finds the minimum cut after running max flow.
     */
    public static MinCutResult findMinCut(FlowNetwork network, int source, int sink) {
        // Run Dinic to compute maximum flow first
        DinicFlow.computeMaxFlow(network, source, sink);

        int n = network.getNumVertices();
        boolean[] visited = new boolean[n];
        Queue<Integer> queue = new ArrayDeque<>();

        // BFS from source in residual network
        visited[source] = true;
        queue.add(source);

        while (!queue.isEmpty()) {
            int v = queue.poll();
            for (FlowEdge e : network.getAdj(v)) {
                int w = e.getTo();
                if (!visited[w] && e.getResidualCapacity() > 1e-9) {
                    visited[w] = true;
                    queue.add(w);
                }
            }
        }

        List<Integer> sPart = new ArrayList<>();
        List<Integer> tPart = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if (visited[i]) sPart.add(i);
            else tPart.add(i);
        }

        // Bottleneck edges are original forward edges from S to T
        List<FlowEdge> bottlenecks = new ArrayList<>();
        double totalCutCapacity = 0.0;

        for (FlowEdge e : network.getAllEdges()) {
            if (visited[e.getFrom()] && !visited[e.getTo()]) {
                bottlenecks.add(e);
                totalCutCapacity += e.getCapacity();
            }
        }

        return new MinCutResult(totalCutCapacity, sPart, tPart, bottlenecks);
    }
}
