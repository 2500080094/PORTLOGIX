package com.portlogix.m4_flow;

import java.util.ArrayDeque;
import java.util.Queue;

/**
 * Module 4 (M4 - CO4): Network Flow
 * Edmonds-Karp Algorithm (BFS-based Shortest Augmenting Path).
 * 
 * PortLogix Use Case:
 * Capacity analysis and maximum cargo throughput determination across port corridors.
 * Guarantees polynomial time termination in O(V * E^2).
 */
public class EdmondsKarp {

    public static class FlowResult {
        public final double maxFlow;
        public final int augmentationSteps;

        public FlowResult(double maxFlow, int augmentationSteps) {
            this.maxFlow = maxFlow;
            this.augmentationSteps = augmentationSteps;
        }

        @Override
        public String toString() {
            return String.format("Edmonds-Karp: Max Flow = %.2f TEU/h (Computed in %d augmentation steps)",
                    maxFlow, augmentationSteps);
        }
    }

    public static FlowResult computeMaxFlow(FlowNetwork network, int source, int sink) {
        network.resetAllFlows();
        double maxFlow = 0.0;
        int steps = 0;
        int n = network.getNumVertices();

        while (true) {
            FlowEdge[] edgeTo = new FlowEdge[n];
            boolean[] visited = new boolean[n];
            Queue<Integer> queue = new ArrayDeque<>();

            queue.add(source);
            visited[source] = true;

            while (!queue.isEmpty() && !visited[sink]) {
                int v = queue.poll();
                for (FlowEdge e : network.getAdj(v)) {
                    int w = e.getTo();
                    if (!visited[w] && e.getResidualCapacity() > 1e-9) {
                        edgeTo[w] = e;
                        visited[w] = true;
                        queue.add(w);
                    }
                }
            }

            if (!visited[sink]) {
                break; // No augmenting path found
            }

            // Find bottleneck capacity along BFS path
            double bottle = Double.POSITIVE_INFINITY;
            for (int v = sink; v != source; v = edgeTo[v].getFrom()) {
                bottle = Math.min(bottle, edgeTo[v].getResidualCapacity());
            }

            // Augment residual flow
            for (int v = sink; v != source; v = edgeTo[v].getFrom()) {
                edgeTo[v].addResidualFlow(bottle);
            }

            maxFlow += bottle;
            steps++;
        }

        return new FlowResult(maxFlow, steps);
    }
}
