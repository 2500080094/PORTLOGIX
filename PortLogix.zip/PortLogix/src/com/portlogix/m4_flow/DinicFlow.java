package com.portlogix.m4_flow;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Queue;

/**
 * Module 4 (M4 - CO4): Network Flow
 * Dinic's Algorithm (Level Graphs & Blocking Flow).
 * 
 * PortLogix Use Case:
 * High-performance throughput optimization in large-scale multi-terminal port networks.
 * Time Complexity: O(V^2 * E), and O(E * sqrt(V)) for unit-capacity matching networks.
 */
public class DinicFlow {

    public static class DinicResult {
        public final double maxFlow;
        public final int phaseCount;

        public DinicResult(double maxFlow, int phaseCount) {
            this.maxFlow = maxFlow;
            this.phaseCount = phaseCount;
        }

        @Override
        public String toString() {
            return String.format("Dinic Flow: Max Flow = %.2f TEU/h (Resolved in %d phases)",
                    maxFlow, phaseCount);
        }
    }

    public static DinicResult computeMaxFlow(FlowNetwork network, int source, int sink) {
        network.resetAllFlows();
        int n = network.getNumVertices();
        int[] level = new int[n];
        int[] ptr = new int[n];
        double totalFlow = 0.0;
        int phases = 0;

        while (bfsLevel(network, source, sink, level)) {
            Arrays.fill(ptr, 0);
            while (true) {
                double pushed = dfsBlock(network, source, sink, Double.POSITIVE_INFINITY, level, ptr);
                if (pushed <= 1e-9) break;
                totalFlow += pushed;
            }
            phases++;
        }

        return new DinicResult(totalFlow, phases);
    }

    private static boolean bfsLevel(FlowNetwork network, int source, int sink, int[] level) {
        Arrays.fill(level, -1);
        level[source] = 0;
        Queue<Integer> queue = new ArrayDeque<>();
        queue.add(source);

        while (!queue.isEmpty()) {
            int v = queue.poll();
            for (FlowEdge e : network.getAdj(v)) {
                int w = e.getTo();
                if (level[w] == -1 && e.getResidualCapacity() > 1e-9) {
                    level[w] = level[v] + 1;
                    queue.add(w);
                }
            }
        }

        return level[sink] != -1;
    }

    private static double dfsBlock(FlowNetwork network, int v, int sink, double flow, int[] level, int[] ptr) {
        if (v == sink || flow <= 1e-9) return flow;

        for (; ptr[v] < network.getAdj(v).size(); ptr[v]++) {
            FlowEdge e = network.getAdj(v).get(ptr[v]);
            int w = e.getTo();

            if (level[w] == level[v] + 1 && e.getResidualCapacity() > 1e-9) {
                double bottle = Math.min(flow, e.getResidualCapacity());
                double pushed = dfsBlock(network, w, sink, bottle, level, ptr);

                if (pushed > 1e-9) {
                    e.addResidualFlow(pushed);
                    return pushed;
                }
            }
        }
        return 0.0;
    }
}
