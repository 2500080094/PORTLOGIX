package com.portlogix.m4_flow;

import com.portlogix.model.Container;
import com.portlogix.model.PortFacility;

import java.util.*;

/**
 * Module 4 (M4 - CO4): Network Flow
 * Maximum Bipartite Matching for Container & Resource Allocation.
 * 
 * PortLogix Use Case:
 * Assigning arriving containers to qualified inspection bays, quay cranes, or storage berths
 * according to physical eligibility constraints (e.g. reefer plug availability, hazmat certification).
 */
public class BipartiteMatching {

    public static class MatchingAssignment {
        public final int maxMatches;
        public final Map<String, String> containerToFacility;
        public final List<String> unassignedContainers;

        public MatchingAssignment(int maxMatches, Map<String, String> containerToFacility, List<String> unassignedContainers) {
            this.maxMatches = maxMatches;
            this.containerToFacility = containerToFacility;
            this.unassignedContainers = unassignedContainers;
        }

        @Override
        public String toString() {
            return String.format("Assigned %d containers to facilities (%d unassigned)",
                    maxMatches, unassignedContainers.size());
        }
    }

    /**
     * Solves maximum bipartite matching between containers and eligible facilities.
     * @param containers Arriving containers
     * @param facilities Port resources with their capacities
     * @param eligibilityMap Map where containerId -> list of eligible facilityIds
     */
    public static MatchingAssignment solveMatching(List<Container> containers, 
                                                    List<PortFacility> facilities, 
                                                    Map<String, List<Integer>> eligibilityMap) {
        int numC = containers.size();
        int numF = facilities.size();
        int source = 0;
        int sink = numC + numF + 1;
        int totalNodes = sink + 1;

        FlowNetwork net = new FlowNetwork(totalNodes);
        net.setVertexName(source, "SOURCE");
        net.setVertexName(sink, "SINK");

        // Container nodes: 1 to numC
        for (int i = 0; i < numC; i++) {
            net.setVertexName(i + 1, containers.get(i).getId());
            net.addEdge(source, i + 1, 1.0); // Each container needs 1 facility
        }

        // Facility nodes: numC + 1 to numC + numF
        for (int j = 0; j < numF; j++) {
            int facNode = numC + 1 + j;
            PortFacility fac = facilities.get(j);
            net.setVertexName(facNode, fac.getName());
            // Facility can process a certain number of concurrent containers
            net.addEdge(facNode, sink, Math.max(1, fac.getMaxThroughputTeuPerHour() / 30));
        }

        // Eligibility edges
        for (int i = 0; i < numC; i++) {
            Container c = containers.get(i);
            List<Integer> allowedFacs = eligibilityMap.get(c.getId());
            if (allowedFacs != null) {
                for (int facId : allowedFacs) {
                    for (int j = 0; j < numF; j++) {
                        if (facilities.get(j).getId() == facId) {
                            net.addEdge(i + 1, numC + 1 + j, 1.0);
                        }
                    }
                }
            }
        }

        DinicFlow.DinicResult res = DinicFlow.computeMaxFlow(net, source, sink);
        int matches = (int) Math.round(res.maxFlow);

        Map<String, String> assignment = new LinkedHashMap<>();
        Set<String> matchedContainers = new HashSet<>();

        for (int i = 0; i < numC; i++) {
            int cNode = i + 1;
            for (FlowEdge e : net.getAdj(cNode)) {
                if (e.getFrom() == cNode && e.getFlow() > 0.5 && e.getTo() != source) {
                    int facIdx = e.getTo() - (numC + 1);
                    assignment.put(containers.get(i).getId(), facilities.get(facIdx).getName());
                    matchedContainers.add(containers.get(i).getId());
                    break;
                }
            }
        }

        List<String> unassigned = new ArrayList<>();
        for (Container c : containers) {
            if (!matchedContainers.contains(c.getId())) {
                unassigned.add(c.getId());
            }
        }

        return new MatchingAssignment(matches, assignment, unassigned);
    }
}
