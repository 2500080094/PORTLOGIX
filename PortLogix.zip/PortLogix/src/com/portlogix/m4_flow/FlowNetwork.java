package com.portlogix.m4_flow;

import java.util.ArrayList;
import java.util.List;

/**
 * Graph representation of the PortLogix cargo transportation network.
 */
public class FlowNetwork {
    private final int numVertices;
    private final List<List<FlowEdge>> adj;
    private final List<FlowEdge> allEdges;
    private String[] vertexNames;

    public FlowNetwork(int numVertices) {
        this.numVertices = numVertices;
        this.adj = new ArrayList<>(numVertices);
        this.allEdges = new ArrayList<>();
        this.vertexNames = new String[numVertices];
        for (int i = 0; i < numVertices; i++) {
            adj.add(new ArrayList<>());
            vertexNames[i] = "Node_" + i;
        }
    }

    public void setVertexName(int v, String name) {
        if (v >= 0 && v < numVertices) {
            vertexNames[v] = name;
        }
    }

    public String getVertexName(int v) {
        return (v >= 0 && v < numVertices) ? vertexNames[v] : "Unknown";
    }

    public void addEdge(int from, int to, double capacity) {
        FlowEdge forward = new FlowEdge(from, to, capacity);
        FlowEdge backward = new FlowEdge(to, from, 0.0);
        forward.setResidual(backward);
        backward.setResidual(forward);
        adj.get(from).add(forward);
        adj.get(to).add(backward);
        allEdges.add(forward);
    }

    public int getNumVertices() { return numVertices; }
    public List<FlowEdge> getAdj(int v) { return adj.get(v); }
    public List<FlowEdge> getAllEdges() { return allEdges; }

    public void resetAllFlows() {
        for (FlowEdge edge : allEdges) {
            edge.resetFlow();
            edge.getResidual().resetFlow();
        }
    }
}
