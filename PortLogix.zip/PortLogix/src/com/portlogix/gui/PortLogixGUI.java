package com.portlogix.gui;

import com.portlogix.m1_strings.*;
import com.portlogix.m2_suffix.*;
import com.portlogix.m3_dp.*;
import com.portlogix.m4_flow.*;
import com.portlogix.m5_np.*;
import com.portlogix.m6_parallel.*;
import com.portlogix.model.CargoAlert;
import com.portlogix.model.Container;
import com.portlogix.model.PortFacility;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.List;

/**
 * PortLogix - Cyber-Maritime Smart Port & Cargo Management GUI.
 * Ultra-Modern Design System with Animated Canvas, Particle Flows,
 * Real-Time Radar, Interactive Charts, Glassmorphic Theme,
 * and In-Depth "How It Works" Algorithmic Walkthroughs for Scenarios 1 to 7.
 */
public class PortLogixGUI extends JFrame {

    // Cyber-Maritime Palette
    public static final Color BG_DARK = new Color(8, 13, 26);
    public static final Color CARD_BG = new Color(17, 28, 56);
    public static final Color CARD_BG_ELEVATED = new Color(24, 39, 75);
    public static final Color BORDER_GLOW = new Color(38, 59, 105);
    public static final Color ACCENT_CYAN = new Color(0, 240, 255);
    public static final Color ACCENT_BLUE = new Color(59, 130, 246);
    public static final Color ACCENT_GREEN = new Color(16, 185, 129);
    public static final Color ACCENT_AMBER = new Color(245, 158, 11);
    public static final Color ACCENT_RED = new Color(239, 68, 68);
    public static final Color ACCENT_PURPLE = new Color(139, 92, 246);
    public static final Color TEXT_WHITE = new Color(248, 250, 252);
    public static final Color TEXT_MUTED = new Color(148, 163, 184);

    private FlowNetwork portNetwork;
    private MinCutAnalyzer.MinCutResult activeMinCut;
    private AnimatedPortCanvas animatedCanvas;
    private BlellochChartCanvas chartCanvas;
    private ThreatRadarCanvas radarCanvas;
    private javax.swing.Timer globalAnimationTimer;
    private float animationPhase = 0.0f;

    public PortLogixGUI() {
        setTitle("PortLogix: Smart Port & Cargo Management Platform (Enterprise TOS)");
        setSize(1320, 890);
        setMinimumSize(new Dimension(1120, 750));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initPortData();
        initComponents();
        startAnimationEngine();
    }

    private void initPortData() {
        portNetwork = new FlowNetwork(12);
        portNetwork.setVertexName(0, "Berth Anchor");
        portNetwork.setVertexName(1, "Quay Crane A");
        portNetwork.setVertexName(2, "Quay Crane B");
        portNetwork.setVertexName(3, "Quay Crane C");
        portNetwork.setVertexName(4, "Buffer Yard North");
        portNetwork.setVertexName(5, "Buffer Yard South");
        portNetwork.setVertexName(6, "Hazmat Bunker");
        portNetwork.setVertexName(7, "Customs Scanner");
        portNetwork.setVertexName(8, "Auto Yard A");
        portNetwork.setVertexName(9, "Auto Yard B");
        portNetwork.setVertexName(10, "Rail Intermodal");
        portNetwork.setVertexName(11, "Outgate Terminal");

        portNetwork.addEdge(0, 1, 120);
        portNetwork.addEdge(0, 2, 110);
        portNetwork.addEdge(0, 3, 90);
        portNetwork.addEdge(1, 4, 70);
        portNetwork.addEdge(1, 5, 60);
        portNetwork.addEdge(2, 4, 65);
        portNetwork.addEdge(2, 5, 70);
        portNetwork.addEdge(3, 5, 80);
        portNetwork.addEdge(3, 6, 40);
        portNetwork.addEdge(4, 7, 90);
        portNetwork.addEdge(4, 8, 80);
        portNetwork.addEdge(5, 7, 70);
        portNetwork.addEdge(5, 9, 95);
        portNetwork.addEdge(6, 7, 35);
        portNetwork.addEdge(7, 8, 60);
        portNetwork.addEdge(7, 9, 70);
        portNetwork.addEdge(7, 10, 50);
        portNetwork.addEdge(8, 10, 85);
        portNetwork.addEdge(8, 11, 90);
        portNetwork.addEdge(9, 10, 75);
        portNetwork.addEdge(9, 11, 100);
        portNetwork.addEdge(10, 11, 130);

        DinicFlow.computeMaxFlow(portNetwork, 0, 11);
        activeMinCut = MinCutAnalyzer.findMinCut(portNetwork, 0, 11);
    }

    private void startAnimationEngine() {
        globalAnimationTimer = new javax.swing.Timer(33, e -> {
            animationPhase += 0.05f;
            if (animationPhase > 100.0f) animationPhase = 0.0f;
            if (animatedCanvas != null && animatedCanvas.isShowing()) {
                animatedCanvas.repaint();
            }
            if (radarCanvas != null && radarCanvas.isShowing()) {
                radarCanvas.repaint();
            }
        });
        globalAnimationTimer.start();
    }

    @Override
    public void dispose() {
        if (globalAnimationTimer != null && globalAnimationTimer.isRunning()) {
            globalAnimationTimer.stop();
        }
        super.dispose();
    }

    private void initComponents() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG_DARK);

        // Header Panel
        root.add(createHeaderPanel(), BorderLayout.NORTH);

        // Custom Styled Tabbed Pane
        JTabbedPane tabs = new JTabbedPane();
        tabs.setOpaque(false);
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabs.setForeground(TEXT_WHITE);
        tabs.setUI(new CyberTabbedPaneUI());

        tabs.addTab("  ⚓ M4: Animated Terminal Flow Canvas  ", createTab1Flow());
        tabs.addTab("  🔍 M1: Threat Radar & Security Scanner  ", createTab2ThreatRadar());
        tabs.addTab("  📄 M2: Customs Suffix & Fraud Indexer  ", createTab3Suffix());
        tabs.addTab("  ⚡ M3: Yard DP & Placard Auto-Repair  ", createTab4DynamicProgrammingPanel());
        tabs.addTab("  🛡️ M5: Safety SAT & Scanner Placement  ", createTab5NP());
        tabs.addTab("  📊 M6: Big Data Parallel Scans & Charts  ", createTab6Parallel());
        tabs.addTab("  📚 7 Scenarios: Algorithm & Operational Guide  ", createTab7ScenariosWalkthrough());

        root.add(tabs, BorderLayout.CENTER);

        // Bottom Live Ticker Bar
        root.add(createTickerBar(), BorderLayout.SOUTH);

        setContentPane(root);
    }

    // -------------------------------------------------------------------------
    // HEADER & KPI METRIC CARDS
    // -------------------------------------------------------------------------
    private JPanel createHeaderPanel() {
        JPanel container = new JPanel(new BorderLayout(8, 8));
        container.setBackground(BG_DARK);
        container.setBorder(new EmptyBorder(12, 18, 6, 18));

        // Top Brand Bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);

        JLabel logo = new JLabel("⚓ PORTLOGIX SMART PORT OS");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        logo.setForeground(ACCENT_CYAN);

        JLabel sub = new JLabel("Enterprise Autonomous Port Control Center — Core DSA Engine (Modules M1-M6 / Scenarios 1-7)");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sub.setForeground(TEXT_MUTED);

        JPanel brandText = new JPanel(new GridLayout(2, 1, 2, 2));
        brandText.setOpaque(false);
        brandText.add(logo);
        brandText.add(sub);
        topBar.add(brandText, BorderLayout.WEST);

        // Live System Badges
        JPanel badgeBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 4));
        badgeBar.setOpaque(false);
        badgeBar.add(createPillBadge("● HARBOR RADAR: ACTIVE", ACCENT_GREEN));
        badgeBar.add(createPillBadge("⚡ THROUGHPUT: 320.0 TEU/H", ACCENT_CYAN));
        badgeBar.add(createPillBadge("🛡️ IMDG THREAT MONITOR: ON", ACCENT_AMBER));
        topBar.add(badgeBar, BorderLayout.EAST);

        container.add(topBar, BorderLayout.NORTH);

        // 4 Large Glassmorphic KPI Cards
        JPanel kpiGrid = new JPanel(new GridLayout(1, 4, 12, 12));
        kpiGrid.setOpaque(false);
        kpiGrid.add(createKpiCard("BERTH DOCKING", "3 Vessels Moored", "M/V EVER GIVEN (IMO 9811000)", ACCENT_CYAN));
        kpiGrid.add(createKpiCard("DISCHARGE CAPACITY", "320.0 TEU / hr", "Dinic Level Graph & Blocking Flow", ACCENT_GREEN));
        kpiGrid.add(createKpiCard("SECURITY INTERCEPT", "7 Alerts Flagged", "Aho-Corasick IMDG Contraband Scanner", ACCENT_RED));
        kpiGrid.add(createKpiCard("PARALLEL WORK-DEPTH", "Max 2,500x Speedup", "Brent's Theorem Task Scheduler", ACCENT_PURPLE));

        container.add(kpiGrid, BorderLayout.SOUTH);
        return container;
    }

    private JPanel createKpiCard(String label, String value, String footer, Color accent) {
        return new GlassCard(14) {
            {
                setLayout(new BorderLayout(4, 4));
                setBorder(new EmptyBorder(10, 14, 10, 14));

                JLabel lLbl = new JLabel(label);
                lLbl.setFont(new Font("Segoe UI", Font.BOLD, 10));
                lLbl.setForeground(TEXT_MUTED);

                JLabel vLbl = new JLabel(value);
                vLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
                vLbl.setForeground(accent);

                JLabel fLbl = new JLabel(footer);
                fLbl.setFont(new Font("Segoe UI", Font.PLAIN, 10));
                fLbl.setForeground(TEXT_WHITE);

                add(lLbl, BorderLayout.NORTH);
                add(vLbl, BorderLayout.CENTER);
                add(fLbl, BorderLayout.SOUTH);
            }
        };
    }

    private JLabel createPillBadge(String text, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 11));
        l.setForeground(color);
        l.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(color, 1, true),
                new EmptyBorder(3, 8, 3, 8)
        ));
        return l;
    }

    private JPanel createTickerBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(new Color(11, 19, 38));
        bar.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(BORDER_GLOW, 1),
                new EmptyBorder(6, 16, 6, 16)
        ));

        JLabel ticker = new JLabel("🟢 PORTLOGIX ENGINE ACTIVE  |  PORT SECTOR: ROTTERDAM GATEWAY 4  |  FLOW ALGORITHM: DINIC O(V²E)  |  CRYPTOGRAPHIC SEAL: 1,000,000,007 VERIFIED");
        ticker.setFont(new Font("Consolas", Font.PLAIN, 11));
        ticker.setForeground(ACCENT_CYAN);
        bar.add(ticker, BorderLayout.WEST);

        JLabel clock = new JLabel("SIMULATION CLOCK: LIVE 60 FPS");
        clock.setFont(new Font("Segoe UI", Font.BOLD, 11));
        clock.setForeground(TEXT_MUTED);
        bar.add(clock, BorderLayout.EAST);
        return bar;
    }

    /**
     * Reusable Educational Explanation Card describing the Port Challenge, How It Works, and Port Action.
     */
    private JPanel createExplanationCard(String title, String problem, String mechanics, String decision, String complexity, Color accent) {
        GlassCard card = new GlassCard(10);
        card.setLayout(new BorderLayout(6, 6));
        card.setBorder(new EmptyBorder(8, 12, 8, 12));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);

        JLabel tLbl = new JLabel("💡 " + title);
        tLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tLbl.setForeground(accent);

        JLabel cBadge = createPillBadge("⚡ " + complexity, accent);

        top.add(tLbl, BorderLayout.WEST);
        top.add(cBadge, BorderLayout.EAST);
        card.add(top, BorderLayout.NORTH);

        JPanel body = new JPanel(new GridLayout(3, 1, 2, 2));
        body.setOpaque(false);

        JLabel pLbl = new JLabel("<html><b>🚢 The Maritime Problem:</b> " + problem + "</html>");
        pLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        pLbl.setForeground(TEXT_WHITE);

        JLabel mLbl = new JLabel("<html><b>⚙️ How It Works:</b> " + mechanics + "</html>");
        mLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        mLbl.setForeground(new Color(203, 213, 225));

        JLabel dLbl = new JLabel("<html><b>🎯 Real-World Port Action:</b> " + decision + "</html>");
        dLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        dLbl.setForeground(ACCENT_GREEN);

        body.add(pLbl);
        body.add(mLbl);
        body.add(dLbl);

        card.add(body, BorderLayout.CENTER);
        return card;
    }

    // -------------------------------------------------------------------------
    // TAB 1: ANIMATED PORT FLOW & BOTTLENECK CANVAS (M4)
    // -------------------------------------------------------------------------
    private JPanel createTab1Flow() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(BG_DARK);
        p.setBorder(new EmptyBorder(10, 14, 10, 14));

        animatedCanvas = new AnimatedPortCanvas(portNetwork, activeMinCut);

        JPanel controls = new GlassCard(10);
        controls.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 6));

        JButton btnDinic = createModernButton("⚡ Run Dinic Max Flow", ACCENT_CYAN);
        JButton btnMinCut = createModernButton("🔴 Highlight Min-Cut Choke Points", ACCENT_RED);
        JButton btnBipartite = createModernButton("⚓ Assign Cranes (Bipartite)", ACCENT_GREEN);

        JLabel hint = new JLabel(" [Glowing Cyan = Active Flow Pipelines | Pulsing Red = Saturated Min-Cut Choke Points]");
        hint.setFont(new Font("Segoe UI", Font.BOLD, 11));
        hint.setForeground(TEXT_MUTED);

        JTextArea out = createTerminalArea(3);

        btnDinic.addActionListener(e -> {
            DinicFlow.DinicResult r = DinicFlow.computeMaxFlow(portNetwork, 0, 11);
            animatedCanvas.setHighlightChoke(false);
            animatedCanvas.repaint();
            out.setText(String.format(">> [Dinic's Algorithm] Pushed blocking flow through level graph in %d phases.\n>> Maximum Terminal Throughput: %.1f TEU/hour | 100%% of cargo safely routed to destination yards.",
                    r.phaseCount, r.maxFlow));
        });

        btnMinCut.addActionListener(e -> {
            activeMinCut = MinCutAnalyzer.findMinCut(portNetwork, 0, 11);
            animatedCanvas.setHighlightChoke(true);
            animatedCanvas.repaint();
            StringBuilder sb = new StringBuilder();
            sb.append(String.format(">> [Max-Flow Min-Cut Theorem] Minimum Cut Capacity: %.1f TEU/h\n", activeMinCut.cutCapacity));
            sb.append(String.format(">> Critical Bottlenecks: %d S-T saturated edges directly limiting total port throughput:\n", activeMinCut.criticalBottleneckEdges.size()));
            for (FlowEdge edge : activeMinCut.criticalBottleneckEdges) {
                sb.append(String.format("   ↳ CHOKE POINT: Node #%d (%s) -> Node #%d (%s) [Cap Limit: %.1f TEU/h]\n",
                        edge.getFrom(), portNetwork.getVertexName(edge.getFrom()),
                        edge.getTo(), portNetwork.getVertexName(edge.getTo()), edge.getCapacity()));
            }
            out.setText(sb.toString());
        });

        btnBipartite.addActionListener(e -> {
            List<Container> incoming = List.of(
                    new Container("MSKU-REEFER", "IMO1", 24, "REEFER", 2, 85, "READY"),
                    new Container("CMAU-HAZMAT", "IMO1", 19, "CLASS_3_FLAMMABLE", 1, 95, "READY"),
                    new Container("COSU-BULK",   "IMO1", 28, "NONE", 4, 60, "READY")
            );
            List<PortFacility> facilities = List.of(
                    new PortFacility(101, "Gantry_Crane_Alpha", PortFacility.FacilityType.QUAY_CRANE, 35),
                    new PortFacility(102, "Hazmat_Inspection_Bay", PortFacility.FacilityType.HAZMAT_SHED, 35),
                    new PortFacility(103, "Reefer_Cold_Terminal", PortFacility.FacilityType.BUFFER_YARD, 35)
            );
            Map<String, List<Integer>> eligibility = Map.of(
                    "MSKU-REEFER", List.of(101, 103),
                    "CMAU-HAZMAT", List.of(102),
                    "COSU-BULK", List.of(101)
            );
            BipartiteMatching.MatchingAssignment assign = BipartiteMatching.solveMatching(incoming, facilities, eligibility);
            StringBuilder sb = new StringBuilder(">> [Bipartite Matching Engine] Dispatched " + assign.maxMatches + " arriving containers:\n");
            assign.containerToFacility.forEach((cid, fac) -> sb.append(String.format("   + Container %s ==> Docked at %s\n", cid, fac)));
            out.setText(sb.toString());
        });

        controls.add(btnDinic);
        controls.add(btnMinCut);
        controls.add(btnBipartite);
        controls.add(hint);

        JPanel northPanel = new JPanel(new BorderLayout(6, 6));
        northPanel.setOpaque(false);
        northPanel.add(createExplanationCard(
                "MODULE 4: HIGH-THROUGHPUT FLOW NETWORK & MIN-CUT BOTTLENECK ANALYSIS",
                "Determine maximum container throughput (TEU/hr) from Berth to Outgate and pinpoint physical corridors restricting port expansion.",
                "Dinic's algorithm builds BFS level graphs and pushes DFS blocking flows in O(V²E). Max-Flow Min-Cut Theorem proves min (S,T) cut capacity exactly equals max flow, identifying saturated choke points.",
                "Identified 3 saturated edges from Berth 0 to Quay Cranes. Management authorizes adding 1 new Quay Gantry Crane to Berth 0 (+80 TEU/h).",
                "O(V²E) Dinic | O(V·E²) Edmonds-Karp",
                ACCENT_CYAN
        ), BorderLayout.NORTH);
        northPanel.add(controls, BorderLayout.SOUTH);

        p.add(northPanel, BorderLayout.NORTH);
        p.add(animatedCanvas, BorderLayout.CENTER);
        p.add(new JScrollPane(out), BorderLayout.SOUTH);
        return p;
    }

    // -------------------------------------------------------------------------
    // TAB 2: THREAT RADAR & SECURITY SCANNER (M1)
    // -------------------------------------------------------------------------
    private JPanel createTab2ThreatRadar() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(BG_DARK);
        p.setBorder(new EmptyBorder(10, 14, 10, 14));

        radarCanvas = new ThreatRadarCanvas();

        JTextArea manifestArea = new JTextArea(
                "CARGO_MANIFEST: BL-2026-ROTTERDAM-00842 | VESSEL: EVER_GIVEN_IMO9811000\n" +
                "CONTAINER_1: MSKU9012347 | INDUSTRIAL SPARE PARTS AND HYDRAULIC DRILLING ACCUMULATORS.\n" +
                "CONTAINER_2: CMAU8765432 | ALERT: SUSPECTED CONTRABAND AND FLAMMABLE_LIQUID SOLVENTS (UN_1993).\n" +
                "CONTAINER_3: HLCU1122334 | CRITICAL WARNING: DETONATOR PACKAGING AND EXPLOSIVE RESIDUES REPORTED.\n" +
                "CONTAINER_4: MAEU7788990 | RADIOACTIVE ISOTOPE SHIELDING LEAK FLAGGED BY QUAYSIDE SENSOR.\n" +
                "CONTAINER_5: MSKU9012347 | REPEATED LOT VERIFICATION BILL OF LADING."
        );
        styleTextArea(manifestArea);

        JTextField searchField = new JTextField("MSKU9012347", 14);
        styleTextField(searchField);

        JComboBox<String> algoSelector = new JComboBox<>(new String[]{
                "Aho-Corasick Multi-Pattern Security Radar",
                "KMP Algorithm (Exact Container ID)",
                "Z-Algorithm (Repeating Pattern Detection)",
                "Rabin-Karp Rolling Hash Scanner"
        });
        styleComboBox(algoSelector);

        JButton btnScan = createModernButton("🔍 Run Threat & String Scan", ACCENT_CYAN);

        String[] cols = {"Alert Pattern", "Severity", "Byte Offset", "Intercepted Manifest Snippet"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        JTable table = new JTable(model);
        styleTable(table);

        btnScan.addActionListener(e -> {
            model.setRowCount(0);
            String text = manifestArea.getText();
            String query = searchField.getText();
            String algo = (String) algoSelector.getSelectedItem();

            if (algo.startsWith("Aho-Corasick")) {
                AhoCorasickAutomaton ac = new AhoCorasickAutomaton();
                ac.addPattern("EXPLOSIVE", "CRITICAL");
                ac.addPattern("CONTRABAND", "CRITICAL");
                ac.addPattern("RADIOACTIVE", "CRITICAL");
                ac.addPattern("FLAMMABLE_LIQUID", "WARNING");
                ac.addPattern("UN_1993", "CRITICAL");
                ac.buildAutomaton();

                List<CargoAlert> alerts = ac.scan(text);
                for (CargoAlert alert : alerts) {
                    model.addRow(new Object[]{
                            alert.getPattern(), alert.getSeverity(), "@ Byte " + alert.getPosition(), alert.getContextSnippet()
                    });
                }
            } else if (algo.startsWith("KMP")) {
                List<Integer> hits = KMPMatcher.searchAll(text, query);
                int[] pi = KMPMatcher.computePiTable(query);
                for (int pos : hits) {
                    int end = Math.min(text.length(), pos + query.length() + 30);
                    model.addRow(new Object[]{
                            query, "KMP MATCH (π=" + Arrays.toString(pi) + ")", "@ Byte " + pos, text.substring(pos, end).replace('\n', ' ')
                    });
                }
            } else if (algo.startsWith("Z-")) {
                List<Integer> hits = ZAlgorithm.search(text, query);
                int period = ZAlgorithm.findSmallestPeriod(query);
                for (int pos : hits) {
                    model.addRow(new Object[]{
                            query, "Z-MATCH (Period=" + period + ")", "@ Byte " + pos, "Matched via linear Z-array prefix function"
                    });
                }
            } else {
                List<Integer> hits = RabinKarpMatcher.search(text, query);
                for (int pos : hits) {
                    model.addRow(new Object[]{
                            query, "RABIN-KARP HASH MATCH", "@ Byte " + pos, "Polynomial rolling hash modulo 1,000,000,007 verified"
                    });
                }
            }
        });

        btnScan.doClick();

        JPanel northPanel = new JPanel(new BorderLayout(6, 6));
        northPanel.setOpaque(false);
        northPanel.add(createExplanationCard(
                "MODULE 1: INBOUND MANIFEST SCANNING & AHO-CORASICK CONTRABAND RADAR",
                "Scan gigabytes of arriving container manifest text streams in real-time to intercept explosive, toxic, and radioactive contraband.",
                "Aho-Corasick builds a Trie with BFS failure transitions & dictionary suffix links. Scans text in a single linear pass O(N + M + Z) regardless of keyword count. KMP uses pi-table to prevent backtracking.",
                "Intercepted [CLASS 1 EXPLOSIVE] and [RADIOACTIVE ISOTOPE] containers. Auto-quarantine diverted them to HAZMAT Bunker 4.",
                "O(N + M + Z) Aho-Corasick | O(N) KMP",
                ACCENT_RED
        ), BorderLayout.NORTH);

        JPanel topSplit = new JPanel(new BorderLayout(10, 10));
        topSplit.setOpaque(false);
        topSplit.add(new JScrollPane(manifestArea), BorderLayout.CENTER);
        topSplit.add(radarCanvas, BorderLayout.EAST);

        JPanel toolBar = new GlassCard(8);
        toolBar.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 6));
        toolBar.add(new JLabel("Search Container / SKU:"));
        toolBar.add(searchField);
        toolBar.add(new JLabel("Algorithm:"));
        toolBar.add(algoSelector);
        toolBar.add(btnScan);

        northPanel.add(topSplit, BorderLayout.CENTER);
        northPanel.add(toolBar, BorderLayout.SOUTH);

        p.add(northPanel, BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        return p;
    }

    // -------------------------------------------------------------------------
    // TAB 3: CUSTOMS SUFFIX & FRAUD INDEXER (M2)
    // -------------------------------------------------------------------------
    private JPanel createTab3Suffix() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(BG_DARK);
        p.setBorder(new EmptyBorder(10, 14, 10, 14));

        JTextArea doc1 = new JTextArea("COMMERCIAL_BILL_OF_LADING_ROTTERDAM_INDUSTRIAL_PARTS_CLEARANCE_STAMP");
        JTextArea doc2 = new JTextArea("CUSTOMS_ENTRY_BILL_OF_LADING_ROTTERDAM_INDUSTRIAL_PARTS_INSPECTION_PASSED");
        styleTextArea(doc1);
        styleTextArea(doc2);

        String[] cols = {"SA Index", "Suffix Starting Pos", "LCP Length", "Indexed Manifest Suffix Phrase"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        JTable table = new JTable(model);
        styleTable(table);

        JButton btnSAIS = createModernButton("⚡ Build SA-IS & Kasai LCP", ACCENT_CYAN);
        JButton btnLCS = createModernButton("🔍 Detect Shared Fraud Clauses", ACCENT_GREEN);
        JTextArea summary = createTerminalArea(3);

        btnSAIS.addActionListener(e -> {
            model.setRowCount(0);
            String text = doc1.getText();
            int[] sa = SAIS.build(text);
            int[] lcp = KasaiLCP.computeLCP(text, sa);
            String lrs = KasaiLCP.findLongestRepeatedSubstring(text, sa, lcp);
            SuffixAutomaton sam = new SuffixAutomaton(text);

            for (int i = 0; i < Math.min(sa.length, 30); i++) {
                int pos = sa[i];
                model.addRow(new Object[]{i, pos, lcp[i], text.substring(pos)});
            }

            summary.setText(String.format(">> [SA-IS Linear Time Suffix Array] %d suffixes indexed in O(N) time.\n>> [Kasai's LCP Algorithm] Longest Repeated Substring: \"%s\"\n>> [Suffix Automaton DAWG] %,d distinct cargo phrases indexed with %d states.",
                    sa.length, lrs, sam.countDistinctSubstrings(), sam.getStateCount()));
        });

        btnLCS.addActionListener(e -> {
            String s1 = doc1.getText();
            String s2 = doc2.getText();
            String common = KasaiLCP.findLongestCommonSubstring(s1, s2);
            summary.setText(String.format(">> [Cross-Customs Document Deduplication]\n>> Longest Identical Legal Text: \"%s\"\n>> Length: %d characters (Guaranteed fraud match between carrier bill and customs invoice)",
                    common, common.length()));
        });

        btnSAIS.doClick();

        JPanel northPanel = new JPanel(new BorderLayout(6, 6));
        northPanel.setOpaque(false);
        northPanel.add(createExplanationCard(
                "MODULE 2: CUSTOMS DECLARATION ARCHIVING & FRAUD/PLAGIARISM INDEXER",
                "Detect duplicate declarations, tariff fraud clauses, and plagiarized bills of lading across historical customs archives.",
                "SA-IS builds full suffix array in linear O(N) time via S/L-type induced sorting. Kasai's algorithm computes LCP array in O(N) using rank invariant h >= h - 1. Suffix Automaton DAWG matches patterns in O(M).",
                "Identified identical 38-character legal description clause between two separate declarations. Triggered audit and froze tariff exemption.",
                "O(N) Linear SA-IS | O(N) Kasai LCP",
                ACCENT_CYAN
        ), BorderLayout.NORTH);

        JPanel split = new JPanel(new GridLayout(2, 1, 6, 6));
        split.setOpaque(false);
        split.add(new JScrollPane(doc1));
        split.add(new JScrollPane(doc2));

        JPanel bar = new GlassCard(8);
        bar.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 6));
        bar.add(btnSAIS);
        bar.add(btnLCS);

        northPanel.add(split, BorderLayout.CENTER);
        northPanel.add(bar, BorderLayout.SOUTH);

        p.add(northPanel, BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        p.add(new JScrollPane(summary), BorderLayout.SOUTH);
        return p;
    }

    // -------------------------------------------------------------------------
    // TAB 4: ADVANCED DYNAMIC PROGRAMMING (M3)
    // -------------------------------------------------------------------------
    private JPanel createTab4DynamicProgrammingPanel() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(BG_DARK);
        p.setBorder(new EmptyBorder(10, 14, 10, 14));

        JPanel northPanel = new JPanel(new BorderLayout(6, 6));
        northPanel.setOpaque(false);
        northPanel.add(createExplanationCard(
                "MODULE 3: GANTRY OCR TRANSPOSITION REPAIR, AGV BITMASK DP & QUERY OPTIMIZER",
                "Repair rusted placard typo reads, load AGVs without mixing hazardous classes, and prevent relational database join timeouts.",
                "Damerau-Levenshtein handles digit transpositions in O(|S1|·|S2|). Bitmask DP explores 2^N states to maximize priority under mutual exclusion. Matrix-Chain Multiplication computes optimal join tree in O(N³).",
                "Placard MSKU9012437 auto-repaired to MSKU9012347 without manual delay. AGV #14 loaded safely. Relational query saved 36% CPU ops.",
                "O(|S1|·|S2|) OCR | O(2^N·N) DP | O(N³) MCM",
                ACCENT_AMBER
        ), BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(2, 2, 12, 12));
        grid.setOpaque(false);

        // Tool 1: Placard OCR Auto-Repair
        JPanel cardOCR = createToolCard("OCR PLACARD AUTO-REPAIR (Damerau-Levenshtein)");
        JTextField ocrIn = new JTextField("MSKU9012437", 12);
        styleTextField(ocrIn);
        JButton btnOCR = createModernButton("Repair Placard", ACCENT_CYAN);
        JTextArea ocrOut = createTerminalArea(4);
        btnOCR.addActionListener(e -> {
            List<String> registered = List.of("MSKU9012347", "CMAU8765432", "COSU4567891", "HLCU1122334");
            DamerauLevenshtein.MatchResult res = DamerauLevenshtein.findBestMatch(ocrIn.getText(), registered);
            ocrOut.setText(String.format("Scanned Placard: '%s'\nAuto-Corrected ID: '%s'\nEdit Operations: %d transposition\nConfidence Score: %.1f%%",
                    ocrIn.getText(), res.target, res.distance, res.similarityScore * 100));
        });
        JPanel ocrBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        ocrBar.setOpaque(false);
        ocrBar.add(new JLabel("Damaged Placard:"));
        ocrBar.add(ocrIn);
        ocrBar.add(btnOCR);
        cardOCR.add(ocrBar, BorderLayout.NORTH);
        cardOCR.add(ocrOut, BorderLayout.CENTER);

        // Tool 2: AGV Bitmask DP
        JPanel cardAGV = createToolCard("CONSTRAINED AGV DISPATCH (Bitmask DP)");
        JButton btnAGV = createModernButton("Optimize AGV Payload", ACCENT_GREEN);
        JTextArea agvOut = createTerminalArea(4);
        btnAGV.addActionListener(e -> {
            List<Container> pool = List.of(
                    new Container("C1-EXPLOSIVE", "IMO1", 12.0, "CLASS_1_EXPLOSIVE", 2, 90, "READY"),
                    new Container("C2-FLAMMABLE", "IMO1", 10.0, "CLASS_3_FLAMMABLE", 4, 95, "READY"),
                    new Container("C3-GENERAL",   "IMO1", 14.0, "NONE",               8, 70, "READY"),
                    new Container("C4-REEFER",    "IMO1",  8.0, "REEFER",             3, 85, "READY")
            );
            boolean[][] conflicts = new boolean[4][4];
            conflicts[0][1] = true;
            conflicts[1][0] = true;
            ContainerBitmaskDP.SelectionResult sel = ContainerBitmaskDP.optimizeSelection(pool, 35.0, conflicts);
            StringBuilder sb = new StringBuilder(String.format("Max Priority: %d | Combined Weight: %.1f MT\nSelected AGV Batch:\n",
                    sel.maxPriority, sel.totalWeight));
            for (Container c : sel.selectedContainers) {
                sb.append(String.format(" + %s [%.1f MT | Prio: %d | %s]\n", c.getId(), c.getWeightMt(), c.getPriorityScore(), c.getHazardClass()));
            }
            agvOut.setText(sb.toString());
        });
        cardAGV.add(btnAGV, BorderLayout.NORTH);
        cardAGV.add(agvOut, BorderLayout.CENTER);

        // Tool 3: MCM Optimizer
        JPanel cardMCM = createToolCard("DATABASE JOIN PIPELINE (Matrix-Chain)");
        JButton btnMCM = createModernButton("Optimize Query Joins", ACCENT_AMBER);
        JTextArea mcmOut = createTerminalArea(4);
        btnMCM.addActionListener(e -> {
            int[] dims = {20, 150, 10, 80, 25};
            String[] tables = {"Vessels", "Manifests", "Containers", "Inspections"};
            MatrixChainOptimizer.MCMResult r = MatrixChainOptimizer.optimize(dims, tables);
            mcmOut.setText(String.format("Optimal Query Tree: %s\nOptimal Cost: %,d operations\nNaive Sequential: %,d operations\nPerformance Gain: %.1f%% saved!",
                    r.optimalParenthesization, r.minOperations, r.naiveOperations, r.getOptimizationPercentage()));
        });
        cardMCM.add(btnMCM, BorderLayout.NORTH);
        cardMCM.add(mcmOut, BorderLayout.CENTER);

        // Tool 4: Optimal BST
        JPanel cardOBST = createToolCard("GATE TARIFF LOOKUP LATENCY (Optimal BST)");
        JButton btnOBST = createModernButton("Build Minimum-Cost BST", ACCENT_PURPLE);
        JTextArea obstOut = createTerminalArea(4);
        btnOBST.addActionListener(e -> {
            String[] keys = {"BERTH", "CUSTOMS", "GATE", "REEFER"};
            double[] pProb = {0.20, 0.15, 0.35, 0.30};
            double[] qProb = {0.05, 0.05, 0.05, 0.05, 0.05};
            OptimalBST.OBSTResult r = OptimalBST.buildOptimalBST(keys, pProb, qProb);
            obstOut.setText(String.format("Min Expected Search Cost: %.4f comparisons\n\nOptimal Tree Hierarchy:\n%s",
                    r.minExpectedCost, r.formatTree()));
        });
        cardOBST.add(btnOBST, BorderLayout.NORTH);
        cardOBST.add(obstOut, BorderLayout.CENTER);

        btnOCR.doClick();
        btnAGV.doClick();
        btnMCM.doClick();
        btnOBST.doClick();

        grid.add(cardOCR);
        grid.add(cardAGV);
        grid.add(cardMCM);
        grid.add(cardOBST);

        p.add(northPanel, BorderLayout.NORTH);
        p.add(grid, BorderLayout.CENTER);
        return p;
    }

    // -------------------------------------------------------------------------
    // TAB 5: NP REDUCTIONS & 2-APPROXIMATION (M5)
    // -------------------------------------------------------------------------
    private JPanel createTab5NP() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(BG_DARK);
        p.setBorder(new EmptyBorder(10, 14, 10, 14));

        JPanel northPanel = new JPanel(new BorderLayout(6, 6));
        northPanel.setOpaque(false);
        northPanel.add(createExplanationCard(
                "MODULE 5: PORT SAFETY 3-SAT SOLVER, KARP REDUCTIONS & 2-APPROX SCANNERS",
                "Verify complex berthing logic constraints and position surveillance scanners to cover all transfer corridors within budget.",
                "DPLL algorithm solves 3-SAT CNF clauses with unit propagation. Karp reductions prove Vertex Cover is NP-Hard. 2-Approximation maximal matching guarantees scanner count <= 2 * OPTIMAL in O(V + E) time.",
                "Proved conflict-free crane movement. Deployed 4 CCTV gamma scanners covering 100% of transfer corridors at minimal capital cost.",
                "O(V + E) 2-Approx | NP-Complete DPLL",
                ACCENT_GREEN
        ), BorderLayout.NORTH);

        JButton btnSAT = createModernButton("⚡ Run DPLL 3-SAT Solver", ACCENT_CYAN);
        JButton btnReduce = createModernButton("🔄 Karp Reductions (3SAT->CLIQUE->IS->VC)", ACCENT_AMBER);
        JButton btnApprox = createModernButton("🛡️ 2-Approx Scanner Placement", ACCENT_GREEN);
        JTextArea out = createTerminalArea(16);

        List<PortSatSolver.Clause> rules = List.of(
                new PortSatSolver.Clause(1, 2),
                new PortSatSolver.Clause(-1, -3),
                new PortSatSolver.Clause(3, -2)
        );

        btnSAT.addActionListener(e -> {
            PortSatSolver.SatResult sat = PortSatSolver.solve(rules, 3);
            out.setText(String.format("=== DPLL 3-SAT PORT SAFETY REGULATIONS SOLVER ===\nFormula: (Berth1 ∨ Berth2) ∧ (¬Berth1 ∨ ¬Crane3) ∧ (Crane3 ∨ ¬Berth2)\n\nResult:\n%s\n\nVerification: Solution guarantees conflict-free crane movement and hazardous segregation.",
                    sat));
        });

        btnReduce.addActionListener(e -> {
            KarpReductions.CliqueReductionInstance clq = KarpReductions.reduce3SatToClique(rules);
            KarpReductions.UndirectedGraph comp = KarpReductions.reduceCliqueToIndependentSet(clq.graph);
            out.setText(String.format("=== COMPUTATIONAL KARP REDUCTIONS PIPELINE ===\n1. 3-SAT -> CLIQUE:\n   Constructed Tripartite Gadget Graph with %d vertices, target clique k=%d.\n\n2. CLIQUE -> INDEPENDENT SET:\n   Complemented graph G_bar (%d vertices). Conflict-free scheduling proven NP-hard.\n\n3. INDEPENDENT SET -> VERTEX COVER:\n   Duality confirms conflict-free schedule size |V| - k = %d.",
                    clq.graph.numVertices, clq.targetK, comp.numVertices, comp.numVertices - clq.targetK));
        });

        btnApprox.addActionListener(e -> {
            KarpReductions.UndirectedGraph corridors = new KarpReductions.UndirectedGraph(8);
            corridors.addEdge(0, 1);
            corridors.addEdge(1, 2);
            corridors.addEdge(2, 3);
            corridors.addEdge(3, 4);
            corridors.addEdge(4, 5);
            corridors.addEdge(5, 6);
            corridors.addEdge(6, 7);
            corridors.addEdge(0, 7);
            corridors.addEdge(1, 5);

            VertexCoverApprox.ApproxResult approx = VertexCoverApprox.compute2Approximation(corridors);
            out.setText(String.format("=== 2-APPROXIMATION SURVEILLANCE SCANNER PLACEMENT ===\nMonitored Yard: 8 Junction Hubs, 9 Transfer Corridors.\n\nOptimal Scanner Deployment: %d Scanners at Hubs %s\nExact Minimal Cover: %d Scanners\nApproximation Ratio: %.2f (Guaranteed <= 2.0x of Absolute Minimum Placement)",
                    approx.approxSize, approx.approximateCover, approx.exactOptimalSize, approx.approximationRatio));
        });

        btnSAT.doClick();

        JPanel bar = new GlassCard(8);
        bar.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 6));
        bar.add(btnSAT);
        bar.add(btnReduce);
        bar.add(btnApprox);

        northPanel.add(bar, BorderLayout.SOUTH);

        p.add(northPanel, BorderLayout.NORTH);
        p.add(new JScrollPane(out), BorderLayout.CENTER);
        return p;
    }

    // -------------------------------------------------------------------------
    // TAB 6: BIG DATA PARALLEL SCANS & CHARTS (M6)
    // -------------------------------------------------------------------------
    private JPanel createTab6Parallel() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(BG_DARK);
        p.setBorder(new EmptyBorder(10, 14, 10, 14));

        JPanel northPanel = new JPanel(new BorderLayout(6, 6));
        northPanel.setOpaque(false);
        northPanel.add(createExplanationCard(
                "MODULE 6: BIG DATA STREAMING, BLELLOCH PARALLEL SCANS & CRANE SCHEDULING",
                "Sort containers without latency spikes, balance railcar weights, sample RFID pings uniformly, and optimize crane speedup.",
                "Randomized QuickSort guarantees expected O(N log N). Blelloch Scan uses Up-Sweep and Down-Sweep trees in O(log N) depth. Reservoir Sampling samples streams in O(k) space. Brent's Theorem bounds speedup Tp <= W/p + D.",
                "Top urgent containers queued to trains. Cumulative track loads balanced evenly. Crane dispatcher allocates 32 parallel trolleys.",
                "O(N) Work / O(log N) Span | W/D Speedup",
                ACCENT_PURPLE
        ), BorderLayout.NORTH);

        double[] sampleTonnage = {12.5, 8.2, 24.0, 15.6, 9.4, 28.1, 19.3, 11.0};
        chartCanvas = new BlellochChartCanvas(sampleTonnage);

        JButton btnScan = createModernButton("⚡ Run Blelloch Parallel Scan", ACCENT_CYAN);
        JButton btnSort = createModernButton("🎲 Randomized QuickSort Benchmark", ACCENT_GREEN);
        JButton btnPrime = createModernButton("🛡️ Miller-Rabin Seal Check", ACCENT_AMBER);
        JButton btnBrent = createModernButton("⚙️ Brent's Task Scheduler", ACCENT_PURPLE);
        JTextArea log = createTerminalArea(4);

        btnScan.addActionListener(e -> {
            BlellochScan.ScanResult res = BlellochScan.computeScan(sampleTonnage);
            chartCanvas.setScanResult(res);
            chartCanvas.repaint();
            log.setText(String.format(">> [Blelloch Work-Efficient Parallel Scan] Input Containers: %d | Parallel Tree Depth: %d\n>> Total Cumulative Berth Tonnage: %.2f MT\n>> Inclusive Prefix Scan: %s",
                    res.originalSize, res.treeDepth, res.totalSum, Arrays.toString(res.inclusiveScan)));
        });

        btnSort.addActionListener(e -> {
            List<Container> test = new ArrayList<>();
            for (int i = 0; i < 2000; i++) {
                test.add(new Container("C" + i, "IMO1", 10 + (i % 25), "NONE", i % 48, (int)(Math.random() * 100), "OK"));
            }
            RandomizedQuickSort.SortStats s = RandomizedQuickSort.sortContainers(test, Comparator.naturalOrder());
            log.setText(String.format(">> [Randomized 3-Way QuickSort] Ranked %,d containers in %,d ns!\n>> Comparisons: %,d | Swaps: %,d | Guaranteed no worst-case O(N²) slowdown.",
                    test.size(), s.timeNanos, s.comparisons, s.swaps));
        });

        btnPrime.addActionListener(e -> {
            BigInteger seal = new BigInteger("1000000007");
            MillerRabinTest.PrimalityResult r = MillerRabinTest.testPrime(seal, 25);
            log.setText(String.format(">> [Miller-Rabin Primality Test] Cryptographic Manifest Seal Key: %s\n>> Result: %s (Confidence: %.8f%% after 25 witness rounds)\n>> Manifest integrity tamper-proof verified.",
                    seal, r.isProbablyPrime ? "GENUINE UNTAMPERED SEAL" : "SECURITY COMPROMISED", r.confidencePercentage));
        });

        btnBrent.addActionListener(e -> {
            BrentTheoremSimulator.ScheduleAnalysis b = BrentTheoremSimulator.analyze(100000, 50);
            log.setText(b.toString());
        });

        btnScan.doClick();

        JPanel bar = new GlassCard(8);
        bar.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 6));
        bar.add(btnScan);
        bar.add(btnSort);
        bar.add(btnPrime);
        bar.add(btnBrent);

        northPanel.add(bar, BorderLayout.SOUTH);

        p.add(northPanel, BorderLayout.NORTH);
        p.add(chartCanvas, BorderLayout.CENTER);
        p.add(new JScrollPane(log), BorderLayout.SOUTH);
        return p;
    }

    // -------------------------------------------------------------------------
    // TAB 7: 7 SCENARIOS OPERATIONAL WALKTHROUGH & ALGORITHM GUIDE
    // -------------------------------------------------------------------------
    private JPanel createTab7ScenariosWalkthrough() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(BG_DARK);
        p.setBorder(new EmptyBorder(10, 14, 10, 14));

        String[] scenarioNames = {
                "Scenario 1: Inbound Manifest Threat Detection & Contraband Radar (M1 - KMP, Aho-Corasick)",
                "Scenario 2: Customs Archive Deduplication & Fraud Detection (M2 - SA-IS, Kasai LCP, DAWG)",
                "Scenario 3: Yard Automation, OCR Placard Repair & AGV Packing (M3 - Damerau-Levenshtein, Bitmask DP)",
                "Scenario 4: Terminal Throughput Capacity & Bottleneck Analysis (M4 - Dinic Flow, Min-Cut Choke Points)",
                "Scenario 5: Hazardous Safety Compliance & Surveillance Placement (M5 - 3-SAT DPLL, 2-Approx)",
                "Scenario 6: Big Data Telemetry, Parallel Scans & Crane Scheduling (M6 - Blelloch Scan, Brent's Law)",
                "Scenario 7: Full Smart-Port Mega-Vessel Turnaround Simulation (End-to-End M1 to M6 Integration)"
        };

        JComboBox<String> scenarioCombo = new JComboBox<>(scenarioNames);
        styleComboBox(scenarioCombo);

        JButton btnRunScenario = createModernButton("▶ Run Live Scenario Simulation", ACCENT_CYAN);

        JTextArea scenarioDetails = createTerminalArea(8);
        scenarioDetails.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        scenarioDetails.setForeground(TEXT_WHITE);

        JTextArea executionLog = createTerminalArea(14);
        executionLog.setFont(new Font("Consolas", Font.PLAIN, 12));
        executionLog.setForeground(ACCENT_CYAN);

        Runnable updateScenarioCard = () -> {
            int idx = scenarioCombo.getSelectedIndex() + 1;
            switch (idx) {
                case 1:
                    scenarioDetails.setText(
                            "SCENARIO 1: INBOUND VESSEL MANIFEST SCANNING & CONTRABAND RADAR (M1)\n" +
                            "---------------------------------------------------------------------------------\n" +
                            "• MARITIME CHALLENGE: Mega-vessel 'M/V EVER GIVEN' docks at Berth 3 with 20,000 TEU.\n" +
                            "  Customs must instantly locate specific containers and detect contraband (explosives, radiation).\n" +
                            "• ALGORITHM MECHANICS: Naive matching resets pointers O(N*M). KMP precomputes the pi-table\n" +
                            "  to ensure text pointer never backtracks (O(N)). Aho-Corasick builds a Trie with BFS failure\n" +
                            "  transitions, detecting ALL contraband keywords simultaneously in ONE single pass O(N + M + Z)!\n" +
                            "• OPERATIONAL ACTION: Contraband containers immediately diverted to HAZMAT Bunker 4."
                    );
                    break;
                case 2:
                    scenarioDetails.setText(
                            "SCENARIO 2: CUSTOMS ARCHIVE DEDUPLICATION & FRAUD DETECTION (M2)\n" +
                            "---------------------------------------------------------------------------------\n" +
                            "• MARITIME CHALLENGE: Shippers submit copied declaration clauses to evade customs taxes.\n" +
                            "• ALGORITHM MECHANICS: SA-IS builds full suffix array in strictly linear O(N) time using\n" +
                            "  S/L-type bucket induced sorting. Kasai's algorithm computes LCP array in O(N) via rank\n" +
                            "  property h >= h - 1. Suffix Automaton (DAWG) recognizes distinct cargo text in O(M).\n" +
                            "• OPERATIONAL ACTION: Detected 38-character fraudulent legal clause; tariff exemption frozen."
                    );
                    break;
                case 3:
                    scenarioDetails.setText(
                            "SCENARIO 3: YARD GANTRY OCR REPAIR & CONSTRAINED AGV DISPATCH (M3)\n" +
                            "---------------------------------------------------------------------------------\n" +
                            "• MARITIME CHALLENGE: Rusted container placards misread by cameras; AGVs must not co-load\n" +
                            "  explosives with flammables; multi-table database queries take millions of operations.\n" +
                            "• ALGORITHM MECHANICS: Damerau-Levenshtein handles swapped digits in O(|S1|*|S2|). Bitmask DP\n" +
                            "  evaluates 2^N state choices under conflict matrices. Matrix-Chain Multiplication computes\n" +
                            "  optimal join parenthesization m[i,j] = min(m[i,k] + m[k+1,j] + cost) in O(N³).\n" +
                            "• OPERATIONAL ACTION: Corrupted placard auto-repaired; safe AGV dispatched; 36% CPU saved."
                    );
                    break;
                case 4:
                    scenarioDetails.setText(
                            "SCENARIO 4: TERMINAL THROUGHPUT CAPACITY & MIN-CUT BOTTLENECK ANALYSIS (M4)\n" +
                            "---------------------------------------------------------------------------------\n" +
                            "• MARITIME CHALLENGE: Find maximum TEU/hr capacity from Berth to Outgate and locate bottlenecks.\n" +
                            "• ALGORITHM MECHANICS: Dinic's Algorithm uses BFS level graphs and DFS blocking flows in O(V²E).\n" +
                            "  Max-Flow Min-Cut Theorem proves min (S,T) cut capacity equals max flow. Edges crossing from S\n" +
                            "  to T in residual graph are the saturated physical bottlenecks restricting the port!\n" +
                            "• OPERATIONAL ACTION: Bottleneck identified between Berth 0 and Cranes; 1 crane added (+80 TEU/h)."
                    );
                    break;
                case 5:
                    scenarioDetails.setText(
                            "SCENARIO 5: HAZARDOUS REGULATIONS & SENSOR 2-APPROXIMATION (M5)\n" +
                            "---------------------------------------------------------------------------------\n" +
                            "• MARITIME CHALLENGE: Verify complex berthing rules and place minimum CCTV scanners.\n" +
                            "• ALGORITHM MECHANICS: DPLL solves 3-SAT CNF clauses with unit propagation. Karp reductions\n" +
                            "  prove Vertex Cover is NP-Hard. 2-Approximation maximal matching picks uncovered edges\n" +
                            "  and adds both endpoints, guaranteeing cover size <= 2 * OPTIMAL in linear O(V + E) time.\n" +
                            "• OPERATIONAL ACTION: Safety certified compliant; 4 scanners deployed covering 100% of corridors."
                    );
                    break;
                case 6:
                    scenarioDetails.setText(
                            "SCENARIO 6: BIG DATA TELEMETRY, PARALLEL SCANS & CRANE SCHEDULING (M6)\n" +
                            "---------------------------------------------------------------------------------\n" +
                            "• MARITIME CHALLENGE: Sort containers without latency spikes, balance train weights, and scale cranes.\n" +
                            "• ALGORITHM MECHANICS: Randomized QuickSort uses random pivot to guarantee expected O(N log N).\n" +
                            "  Blelloch Parallel Scan computes prefix sums in O(N) work and O(log N) depth. Reservoir Sampling\n" +
                            "  monitors continuous RFID stream in O(k) memory. Brent's Theorem bounds speedup Tp <= W/p + D.\n" +
                            "• OPERATIONAL ACTION: Priority containers offloaded; rail loads balanced; 32 crane trolleys assigned."
                    );
                    break;
                case 7:
                    scenarioDetails.setText(
                            "SCENARIO 7: FULL SMART-PORT MEGA-VESSEL TURNAROUND SIMULATION (M1 - M6)\n" +
                            "---------------------------------------------------------------------------------\n" +
                            "• MARITIME CHALLENGE: Orchestrate the complete 18.4-hour turnaround of 'M/V EVER GIVEN' (20,000 TEU).\n" +
                            "• ALGORITHM MECHANICS: End-to-end integration: M1 Intercepts Contraband -> M2 Audits Tariffs\n" +
                            "  -> M3 Repairs Placards & Dispatches AGVs -> M4 Optimizes Flow & Bypasses Min-Cut Bottlenecks\n" +
                            "  -> M5 Validates Safety Constraints & Places Scanners -> M6 Balances Train Weights & Cranes.\n" +
                            "• OPERATIONAL ACTION: 100% security intercept, 38% faster turnaround, zero safety accidents."
                    );
                    break;
            }
        };

        scenarioCombo.addActionListener(e -> updateScenarioCard.run());
        updateScenarioCard.run();

        btnRunScenario.addActionListener(e -> {
            int sel = scenarioCombo.getSelectedIndex() + 1;
            StringBuilder log = new StringBuilder();
            log.append("================================================================================\n");
            log.append(String.format(" >>> EXECUTING SCENARIO %d SIMULATION LIVE IN TERMINAL CONSOLE...\n", sel));
            log.append("================================================================================\n");

            switch (sel) {
                case 1:
                    log.append("[STEP 1] Ingested Manifest Stream (2,840 bytes). Precomputing KMP Failure Function:\n");
                    int[] pi = KMPMatcher.computePiTable("MSKU9012347");
                    log.append(String.format(" -> KMP pi-table: %s\n", Arrays.toString(pi)));
                    List<Integer> kmpHits = KMPMatcher.searchAll("MANIFEST CONTAINER MSKU9012347 VERIFIED MSKU9012347", "MSKU9012347");
                    log.append(String.format(" -> KMP exact matches found at byte offsets: %s\n", kmpHits));
                    AhoCorasickAutomaton ac = new AhoCorasickAutomaton();
                    ac.addPattern("EXPLOSIVE", "CRITICAL");
                    ac.addPattern("RADIOACTIVE", "CRITICAL");
                    ac.buildAutomaton();
                    List<CargoAlert> alerts = ac.scan("ALERT: CONTAINER HLCU1122334 CONTAINS EXPLOSIVE DETONATORS AND RADIOACTIVE TRACES");
                    log.append(String.format(" -> Aho-Corasick Multi-Pattern Radar Flagged %d Threats in 1 pass:\n", alerts.size()));
                    for (CargoAlert a : alerts) {
                        log.append(String.format("    [ALERT %s] Pattern '%s' @ Byte %d\n", a.getSeverity(), a.getPattern(), a.getPosition()));
                    }
                    log.append(" -> ACTION: Hazardous containers quarantined to HAZMAT Bunker 4.\n");
                    break;

                case 2:
                    String docA = "BILL_OF_LADING_ROTTERDAM_INDUSTRIAL_PARTS";
                    String docB = "CUSTOMS_ENTRY_ROTTERDAM_INDUSTRIAL_PARTS";
                    int[] sa = SAIS.build(docA);
                    int[] lcp = KasaiLCP.computeLCP(docA, sa);
                    String lrs = KasaiLCP.findLongestRepeatedSubstring(docA, sa, lcp);
                    String fraud = KasaiLCP.findLongestCommonSubstring(docA, docB);
                    log.append(String.format(" -> SA-IS Suffix Array: %d suffixes sorted in linear O(N) time.\n", sa.length));
                    log.append(String.format(" -> Kasai LCP Longest Repeated Text: \"%s\"\n", lrs));
                    log.append(String.format(" -> Shared Plagiarized Legal Clause: \"%s\" (%d chars)\n", fraud, fraud.length()));
                    log.append(" -> ACTION: Tariff exemption revoked; audit initiated.\n");
                    break;

                case 3:
                    DamerauLevenshtein.MatchResult ocr = DamerauLevenshtein.findBestMatch("MSKU9012437", List.of("MSKU9012347", "CMAU8765432"));
                    log.append(String.format(" -> Optical OCR Auto-Repair: '%s' -> Target: '%s' (Conf: %.1f%%)\n",
                            "MSKU9012437", ocr.target, ocr.similarityScore * 100));
                    List<Container> pool = List.of(
                            new Container("C1-EXPLOSIVE", "IMO1", 12.0, "CLASS_1_EXPLOSIVE", 2, 90, "READY"),
                            new Container("C2-FLAMMABLE", "IMO1", 10.0, "CLASS_3_FLAMMABLE", 4, 95, "READY"),
                            new Container("C3-GENERAL",   "IMO1", 14.0, "NONE",               8, 70, "READY")
                    );
                    boolean[][] conf = new boolean[3][3];
                    conf[0][1] = conf[1][0] = true;
                    ContainerBitmaskDP.SelectionResult agv = ContainerBitmaskDP.optimizeSelection(pool, 30.0, conf);
                    log.append(String.format(" -> Bitmask DP Payload Optimization: Max Score: %d | Total Weight: %.1f MT\n",
                            agv.maxPriority, agv.totalWeight));
                    MatrixChainOptimizer.MCMResult mcm = MatrixChainOptimizer.optimize(new int[]{20, 150, 10, 80, 25}, new String[]{"T1","T2","T3","T4"});
                    log.append(String.format(" -> Relational Query Join Optimization: %s (Saved %.1f%% CPU operations)\n",
                            mcm.optimalParenthesization, mcm.getOptimizationPercentage()));
                    break;

                case 4:
                    DinicFlow.DinicResult dinic = DinicFlow.computeMaxFlow(portNetwork, 0, 11);
                    MinCutAnalyzer.MinCutResult cut = MinCutAnalyzer.findMinCut(portNetwork, 0, 11);
                    log.append(String.format(" -> Dinic Max Flow: %.1f TEU/hour across 12-Node Terminal Grid.\n", dinic.maxFlow));
                    log.append(String.format(" -> Min-Cut Capacity: %.1f TEU/hour (Satisfies Max-Flow Min-Cut Theorem)\n", cut.cutCapacity));
                    log.append(String.format(" -> Saturated Choke Edges: %d bottleneck corridors limiting port throughput:\n", cut.criticalBottleneckEdges.size()));
                    for (FlowEdge edge : cut.criticalBottleneckEdges) {
                        log.append(String.format("    * Node %d (%s) -> Node %d (%s) [Cap Limit: %.1f TEU/h]\n",
                                edge.getFrom(), portNetwork.getVertexName(edge.getFrom()),
                                edge.getTo(), portNetwork.getVertexName(edge.getTo()), edge.getCapacity()));
                    }
                    log.append(" -> ACTION: Capital approved for 1 additional Gantry Crane at Berth 0 (+80 TEU/h).\n");
                    break;

                case 5:
                    List<PortSatSolver.Clause> rules = List.of(
                            new PortSatSolver.Clause(1, 2),
                            new PortSatSolver.Clause(-1, -3),
                            new PortSatSolver.Clause(3, -2)
                    );
                    PortSatSolver.SatResult sat = PortSatSolver.solve(rules, 3);
                    log.append(String.format(" -> DPLL 3-SAT Safety Solver: %s\n", sat));
                    KarpReductions.UndirectedGraph corridors = new KarpReductions.UndirectedGraph(8);
                    corridors.addEdge(0, 1); corridors.addEdge(1, 2); corridors.addEdge(2, 3);
                    corridors.addEdge(3, 4); corridors.addEdge(4, 5); corridors.addEdge(5, 6);
                    corridors.addEdge(6, 7); corridors.addEdge(0, 7); corridors.addEdge(1, 5);
                    VertexCoverApprox.ApproxResult approx = VertexCoverApprox.compute2Approximation(corridors);
                    log.append(String.format(" -> 2-Approx Vertex Cover: %d Scanners at Hubs %s (Ratio: %.2f <= 2.0x)\n",
                            approx.approxSize, approx.approximateCover, approx.approximationRatio));
                    log.append(" -> ACTION: Zero hazardous accidents; 100% corridor coverage guaranteed.\n");
                    break;

                case 6:
                    List<Container> test = new ArrayList<>();
                    for (int i = 0; i < 1000; i++) test.add(new Container("C" + i, "IMO1", 10 + (i % 25), "NONE", i % 48, (int)(Math.random() * 100), "OK"));
                    RandomizedQuickSort.SortStats ss = RandomizedQuickSort.sortContainers(test, Comparator.naturalOrder());
                    log.append(String.format(" -> Randomized QuickSort: Ranked %d containers in %d ns (0 worst-case degradation)\n", test.size(), ss.timeNanos));
                    double[] tw = {12.5, 8.2, 24.0, 15.6, 9.4, 28.1, 19.3, 11.0};
                    BlellochScan.ScanResult bRes = BlellochScan.computeScan(tw);
                    log.append(String.format(" -> Blelloch Parallel Scan: Total Cumulative Track Load: %.2f MT (Tree Depth: %d)\n", bRes.totalSum, bRes.treeDepth));
                    BrentTheoremSimulator.ScheduleAnalysis brent = BrentTheoremSimulator.analyze(80000, 40);
                    log.append(String.format(" -> Brent's Law: Max Speedup W/D = %.1fx | Optimal Crane Trolleys: %d\n", brent.maxTheoreticalSpeedup, brent.optimalProcessorCount));
                    break;

                case 7:
                    log.append("[T+00:00] Berthing M/V EVER GIVEN (20,124 TEU) at Quay 3.\n");
                    log.append("[T+01:15] M1 Aho-Corasick scanned manifest -> 2 Contraband containers quarantined to Bunker 4.\n");
                    log.append("[T+03:30] M2 SA-IS indexed 2,840 suffixes -> Plagiarized tariff clause caught; $45,000 duty recovered.\n");
                    log.append("[T+06:00] M3 Damerau-Levenshtein fixed OCR placard 'MSKU9012437' -> Bitmask DP loaded AGV #14 safely.\n");
                    log.append("[T+10:30] M4 Dinic algorithm routed peak 320 TEU/h -> Min-Cut bypassed bottleneck corridors.\n");
                    log.append("[T+14:00] M5 DPLL certified berthing rules -> 2-Approx deployed 4 gamma scanners saving $350,000.\n");
                    log.append("[T+18:24] M6 Blelloch Scan balanced rail weights -> Brent's law allocated 32 crane trolleys.\n");
                    log.append("\n================================================================================\n");
                    log.append(">>> TURNAROUND COMPLETE: 18.4 Hours (38% Faster) | 0 Safety Violations | 100% Cleared!\n");
                    log.append("================================================================================\n");
                    break;
            }
            executionLog.setText(log.toString());
        });

        JPanel toolBar = new GlassCard(8);
        toolBar.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 6));
        toolBar.add(new JLabel("Select Scenario:"));
        toolBar.add(scenarioCombo);
        toolBar.add(btnRunScenario);

        JPanel topCard = new JPanel(new BorderLayout(6, 6));
        topCard.setOpaque(false);
        topCard.add(toolBar, BorderLayout.NORTH);
        topCard.add(new JScrollPane(scenarioDetails), BorderLayout.CENTER);

        p.add(topCard, BorderLayout.NORTH);
        p.add(new JScrollPane(executionLog), BorderLayout.CENTER);

        return p;
    }

    // =========================================================================
    // CUSTOM VISUALIZATION CANVASES WITH ANIMATION
    // =========================================================================

    /**
     * Animated Harbor Canvas with vessel graphics, cranes, flowing particles, and pulsing choke points.
     */
    private class AnimatedPortCanvas extends JPanel {
        private final FlowNetwork net;
        private MinCutAnalyzer.MinCutResult minCut;
        private boolean highlightChoke = true;

        private final Point[] positions = {
                new Point(80, 240),   // 0: Berth Anchor (Source)
                new Point(240, 110),  // 1: Quay Crane A
                new Point(240, 240),  // 2: Quay Crane B
                new Point(240, 370),  // 3: Quay Crane C
                new Point(440, 150),  // 4: Buffer Yard North
                new Point(440, 320),  // 5: Buffer Yard South
                new Point(440, 440),  // 6: Hazmat Bunker
                new Point(640, 240),  // 7: Customs Scanner
                new Point(820, 150),  // 8: Auto Yard A
                new Point(820, 330),  // 9: Auto Yard B
                new Point(980, 200),  // 10: Rail Intermodal
                new Point(1120, 240)  // 11: Outgate Terminal (Sink)
        };

        public AnimatedPortCanvas(FlowNetwork net, MinCutAnalyzer.MinCutResult minCut) {
            this.net = net;
            this.minCut = minCut;
            setBackground(CARD_BG);
            setBorder(new LineBorder(BORDER_GLOW, 1));
        }

        public void setHighlightChoke(boolean val) {
            this.highlightChoke = val;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();

            // Background cyber-grid
            g2.setColor(new Color(14, 23, 46));
            for (int x = 0; x < w; x += 30) g2.drawLine(x, 0, x, h);
            for (int y = 0; y < h; y += 30) g2.drawLine(0, y, w, y);

            // Water harbor basin at left
            GradientPaint waterGrad = new GradientPaint(0, 0, new Color(5, 20, 45, 180), 160, 0, new Color(8, 13, 26, 0));
            g2.setPaint(waterGrad);
            g2.fillRect(0, 0, 160, h);

            // Moored Vessel graphic
            g2.setColor(new Color(30, 58, 110));
            g2.fillRoundRect(20, 140, 50, 200, 16, 16);
            g2.setColor(ACCENT_CYAN);
            g2.drawRoundRect(20, 140, 50, 200, 16, 16);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 10));
            g2.drawString("M/V EVER GIVEN", 16, 132);

            // Draw Corridors (Flow Edges)
            for (FlowEdge e : net.getAllEdges()) {
                if (e.getCapacity() <= 0) continue;
                Point p1 = positions[e.getFrom()];
                Point p2 = positions[e.getTo()];

                boolean isChoke = highlightChoke && minCut != null && minCut.criticalBottleneckEdges.contains(e);

                if (isChoke) {
                    float pulse = (float) (Math.sin(animationPhase * 4.0) + 1.0) / 2.0f;
                    int alpha = 120 + (int)(pulse * 135);
                    g2.setColor(new Color(239, 68, 68, alpha));
                    g2.setStroke(new BasicStroke(3.5f));
                } else if (e.getFlow() > 0) {
                    g2.setColor(new Color(0, 240, 255, 160));
                    g2.setStroke(new BasicStroke(2.0f));
                } else {
                    g2.setColor(new Color(38, 59, 105, 100));
                    g2.setStroke(new BasicStroke(1.0f));
                }

                g2.drawLine(p1.x, p1.y, p2.x, p2.y);

                // Animated Flow Particles
                if (e.getFlow() > 0) {
                    for (int i = 0; i < 3; i++) {
                        float particlePos = (animationPhase * 0.4f + (float) i / 3.0f) % 1.0f;
                        int px = (int) (p1.x + (p2.x - p1.x) * particlePos);
                        int py = (int) (p1.y + (p2.y - p1.y) * particlePos);
                        g2.setColor(isChoke ? ACCENT_RED : ACCENT_CYAN);
                        g2.fillOval(px - 3, py - 3, 6, 6);
                    }
                }

                // Capacity labels
                int midX = (p1.x + p2.x) / 2;
                int midY = (p1.y + p2.y) / 2;
                g2.setFont(new Font("Consolas", Font.PLAIN, 9));
                g2.setColor(isChoke ? ACCENT_RED : TEXT_MUTED);
                g2.drawString(String.format("%.0f/%.0f", e.getFlow(), e.getCapacity()), midX - 10, midY - 4);
            }

            // Draw Facility Nodes
            for (int i = 0; i < 12; i++) {
                Point pt = positions[i];
                boolean isSource = (i == 0);
                boolean isSink = (i == 11);

                Color nodeFill = isSource ? ACCENT_CYAN : (isSink ? ACCENT_GREEN : CARD_BG_ELEVATED);
                Color ringColor = isSource ? Color.WHITE : (isSink ? ACCENT_GREEN : BORDER_GLOW);

                g2.setColor(new Color(11, 19, 38, 220));
                g2.fillOval(pt.x - 16, pt.y - 16, 32, 32);

                g2.setColor(ringColor);
                g2.setStroke(new BasicStroke(2.0f));
                g2.drawOval(pt.x - 16, pt.y - 16, 32, 32);

                g2.setColor(nodeFill);
                g2.fillOval(pt.x - 8, pt.y - 8, 16, 16);

                // Node Names
                g2.setFont(new Font("Segoe UI", Font.BOLD, 10));
                g2.setColor(TEXT_WHITE);
                g2.drawString(net.getVertexName(i), pt.x - 28, pt.y + 28);
            }

            g2.dispose();
        }
    }

    /**
     * Live Circular Threat Radar Canvas with sweeping beam and alert blips.
     */
    private class ThreatRadarCanvas extends JPanel {
        private final List<Point> threatBlips = List.of(
                new Point(120, 80), new Point(70, 140), new Point(145, 120), new Point(50, 70)
        );

        public ThreatRadarCanvas() {
            setPreferredSize(new Dimension(220, 190));
            setBackground(CARD_BG);
            setBorder(new LineBorder(BORDER_GLOW, 1));
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int cx = getWidth() / 2;
            int cy = getHeight() / 2;
            int radius = Math.min(cx, cy) - 16;

            // Concentric radar rings
            g2.setColor(new Color(16, 185, 129, 60));
            g2.drawOval(cx - radius, cy - radius, radius * 2, radius * 2);
            g2.drawOval(cx - radius * 2 / 3, cy - radius * 2 / 3, radius * 4 / 3, radius * 4 / 3);
            g2.drawOval(cx - radius / 3, cy - radius / 3, radius * 2 / 3, radius * 2 / 3);
            g2.drawLine(cx - radius, cy, cx + radius, cy);
            g2.drawLine(cx, cy - radius, cx, cy + radius);

            // Rotating sweep beam
            double angle = animationPhase * 2.0;
            int bx = (int) (cx + radius * Math.cos(angle));
            int by = (int) (cy + radius * Math.sin(angle));

            g2.setColor(ACCENT_GREEN);
            g2.setStroke(new BasicStroke(1.8f));
            g2.drawLine(cx, cy, bx, by);

            // Pulsing threat blips
            float pulse = (float) (Math.sin(animationPhase * 5.0) + 1.0) / 2.0f;
            for (Point b : threatBlips) {
                g2.setColor(new Color(239, 68, 68, (int)(150 + pulse * 105)));
                g2.fillOval(b.x - 4, b.y - 4, 8, 8);
                g2.setColor(ACCENT_RED);
                g2.drawOval(b.x - 6, b.y - 6, 12, 12);
            }

            g2.setFont(new Font("Segoe UI", Font.BOLD, 9));
            g2.setColor(ACCENT_RED);
            g2.drawString("4 THREATS TRACKED", 10, getHeight() - 8);

            g2.dispose();
        }
    }

    /**
     * Interactive Blelloch Parallel Scan Bar Chart Canvas.
     */
    private static class BlellochChartCanvas extends JPanel {
        private final double[] original;
        private BlellochScan.ScanResult result;

        public BlellochChartCanvas(double[] original) {
            this.original = original;
            this.result = BlellochScan.computeScan(original);
            setBackground(CARD_BG);
            setBorder(new LineBorder(BORDER_GLOW, 1));
        }

        public void setScanResult(BlellochScan.ScanResult r) {
            this.result = r;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();
            int pad = 40;
            int barCount = original.length;
            int barWidth = (w - pad * 2) / (barCount * 2);

            double maxVal = result != null ? result.totalSum : 30.0;
            if (maxVal <= 0) maxVal = 1.0;

            // Grid lines
            g2.setColor(new Color(38, 59, 105, 80));
            g2.drawLine(pad, h - pad, w - pad, h - pad);
            g2.drawLine(pad, pad, pad, h - pad);

            for (int i = 0; i < barCount; i++) {
                int xOrig = pad + i * barWidth * 2;
                int xScan = xOrig + barWidth;

                double origVal = original[i];
                double scanVal = result != null ? result.inclusiveScan[i] : origVal;

                int hOrig = (int) ((origVal / maxVal) * (h - pad * 2));
                int hScan = (int) ((scanVal / maxVal) * (h - pad * 2));

                // Individual Tonnage Bar (Blue)
                g2.setColor(ACCENT_BLUE);
                g2.fillRect(xOrig, h - pad - hOrig, barWidth - 2, hOrig);

                // Cumulative Prefix Sum Bar (Cyan Glowing)
                g2.setColor(ACCENT_CYAN);
                g2.fillRect(xScan, h - pad - hScan, barWidth - 2, hScan);

                g2.setFont(new Font("Segoe UI", Font.PLAIN, 9));
                g2.setColor(TEXT_WHITE);
                g2.drawString("C" + (i + 1), xOrig + 4, h - pad + 14);
            }

            // Legend
            g2.setFont(new Font("Segoe UI", Font.BOLD, 10));
            g2.setColor(ACCENT_BLUE);
            g2.fillRect(w - 240, 16, 12, 12);
            g2.setColor(TEXT_WHITE);
            g2.drawString("Container Load (MT)", w - 222, 26);

            g2.setColor(ACCENT_CYAN);
            g2.fillRect(w - 110, 16, 12, 12);
            g2.setColor(TEXT_WHITE);
            g2.drawString("Blelloch Cumulative", w - 92, 26);

            g2.dispose();
        }
    }

    // =========================================================================
    // UI UTILITY BUILDERS & CYBER THEME HELPERS
    // =========================================================================

    public static JButton createModernButton(String text, Color accent) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 11));
        btn.setForeground(TEXT_WHITE);
        btn.setBackground(CARD_BG_ELEVATED);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(accent, 1, true),
                new EmptyBorder(6, 14, 6, 14)
        ));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(accent);
                btn.setForeground(BG_DARK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(CARD_BG_ELEVATED);
                btn.setForeground(TEXT_WHITE);
            }
        });
        return btn;
    }

    private static JPanel createToolCard(String title) {
        GlassCard card = new GlassCard(10);
        card.setLayout(new BorderLayout(6, 6));
        card.setBorder(new EmptyBorder(10, 12, 10, 12));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
        titleLbl.setForeground(ACCENT_CYAN);

        card.add(titleLbl, BorderLayout.NORTH);
        return card;
    }

    private static JTextArea createTerminalArea(int rows) {
        JTextArea area = new JTextArea(rows, 40);
        area.setBackground(new Color(6, 10, 20));
        area.setForeground(ACCENT_CYAN);
        area.setFont(new Font("Consolas", Font.PLAIN, 11));
        area.setCaretColor(ACCENT_CYAN);
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(BORDER_GLOW, 1),
                new EmptyBorder(6, 8, 6, 8)
        ));
        return area;
    }

    private static void styleTextArea(JTextArea t) {
        t.setBackground(CARD_BG);
        t.setForeground(TEXT_WHITE);
        t.setFont(new Font("Consolas", Font.PLAIN, 11));
        t.setCaretColor(ACCENT_CYAN);
        t.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(BORDER_GLOW, 1),
                new EmptyBorder(6, 8, 6, 8)
        ));
    }

    private static void styleTextField(JTextField f) {
        f.setBackground(CARD_BG);
        f.setForeground(TEXT_WHITE);
        f.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        f.setCaretColor(ACCENT_CYAN);
        f.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(BORDER_GLOW, 1),
                new EmptyBorder(4, 6, 4, 6)
        ));
    }

    private static void styleComboBox(JComboBox<String> c) {
        c.setBackground(CARD_BG);
        c.setForeground(TEXT_WHITE);
        c.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        c.setBorder(new LineBorder(BORDER_GLOW, 1));
    }

    private static void styleTable(JTable t) {
        t.setBackground(CARD_BG);
        t.setForeground(TEXT_WHITE);
        t.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        t.setRowHeight(24);
        t.setGridColor(BORDER_GLOW);
        t.setShowVerticalLines(true);
        t.setShowHorizontalLines(true);
        t.getTableHeader().setBackground(CARD_BG_ELEVATED);
        t.getTableHeader().setForeground(ACCENT_CYAN);
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));

        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object val, boolean isSel, boolean hasFocus, int row, int col) {
                Component c = super.getTableCellRendererComponent(table, val, isSel, hasFocus, row, col);
                c.setBackground(row % 2 == 0 ? CARD_BG : CARD_BG_ELEVATED);
                if (val != null && val.toString().contains("CRITICAL")) {
                    c.setForeground(ACCENT_RED);
                    setFont(getFont().deriveFont(Font.BOLD));
                } else if (val != null && val.toString().contains("WARNING")) {
                    c.setForeground(ACCENT_AMBER);
                } else {
                    c.setForeground(TEXT_WHITE);
                }
                return c;
            }
        });
    }

    private static class CyberTabbedPaneUI extends BasicTabbedPaneUI {
        @Override
        protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (isSelected) {
                g2.setColor(CARD_BG_ELEVATED);
                g2.fillRoundRect(x, y, w, h + 4, 8, 8);
                g2.setColor(ACCENT_CYAN);
                g2.fillRect(x + 6, y + h - 3, w - 12, 3);
            } else {
                g2.setColor(CARD_BG);
                g2.fillRoundRect(x, y + 2, w, h, 6, 6);
            }
            g2.dispose();
        }

        @Override
        protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {
            // Borderless modern look
        }
    }

    public static class GlassCard extends JPanel {
        private final int radius;

        public GlassCard(int radius) {
            this.radius = radius;
            setOpaque(false);
            setBackground(CARD_BG);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g2.setColor(BORDER_GLOW);
            g2.setStroke(new BasicStroke(1.0f));
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PortLogixGUI().setVisible(true));
    }
}
