# PortLogix – Smart Port & Cargo Management Platform
**Enterprise-Grade Smart Port Platform Powered by Advanced Data Structures & Algorithms in Java**

---

## ⚓ Project Overview
**PortLogix** is a simulation and operations management platform designed for modern, automated maritime container terminals (such as the Port of Rotterdam, Singapore, and Shanghai). It orchestrates large-scale maritime logistics data across ships, containers, quay cranes, automated guided vehicles (AGVs), inspection bays, and intermodal rail corridors.

The platform provides practical implementations of core algorithms across all 6 Data Structures & Algorithms modules (M1 to M6 / CO1 to CO6) in pure Java, with zero external dependencies, making it directly runnable in **Eclipse IDE** and from the command line.

---

## 🚀 How to Run in Eclipse IDE

Since the repository is preconfigured with standard Eclipse metadata (`.project`, `.classpath`, and `.settings`), importing and running it in Eclipse takes less than 30 seconds:

### Step 1: Open Eclipse
Launch Eclipse IDE on your machine (e.g., using the desktop shortcut).

### Step 2: Import the Project
1. In Eclipse, click **File** → **Open Projects from File System...** (or **Import...** → **General** → **Existing Projects into Workspace**).
2. Click **Directory...** and browse to this folder:
   ```
   C:\Users\LENOVO\OneDrive\Desktop\PortLogix
   ```
3. Ensure **PortLogix** is checked in the project list.
4. Click **Finish**.

### Step 3: Run the Application
1. In the **Package Explorer** pane on the left, navigate to:
   ```
   PortLogix -> src -> com.portlogix -> PortLogixApp.java
   ```
2. **Right-click** `PortLogixApp.java` → **Run As** → **Java Application**.
3. The interactive console dashboard will launch in Eclipse's **Console** view!
4. To launch the Swing Graphical Dashboard, select option `[7]` from the menu, or right-click `com.portlogix.gui.PortLogixGUI.java` → **Run As** → **Java Application**.
5. To execute the automated test suite, right-click `com.portlogix.benchmark.ComprehensiveTests.java` → **Run As** → **Java Application**.

---

## 💻 Running from Command Line / PowerShell

You can also compile and run the project directly from PowerShell or Command Prompt:

### 1. Compile All Classes:
```powershell
$files = (Get-ChildItem -Path src -Recurse -Filter *.java).FullName
javac -d bin $files
```

### 2. Run Comprehensive Automated Test Suite (45 Tests):
```powershell
java -cp bin com.portlogix.benchmark.ComprehensiveTests
```

### 3. Run Interactive Terminal Operating System (TOS):
```powershell
java -cp bin com.portlogix.PortLogixApp
```
- Select **`[1]`** to launch the **Animated Desktop Graphical Dashboard (Swing GUI)**!
- Select **`[2]` to `[7]`** to execute real-world maritime operational workflows.
- Select **`[8]`** to run the 45 automated algorithm integrity tests.

### 4. Direct Launch of Graphical Dashboard:
```powershell
java -cp bin com.portlogix.gui.PortLogixGUI
```

---

## 📊 DSA Course Outcome Mapping & Algorithm Complexity

| Module & Course Outcome | Algorithm | Port Logistics Application | Time Complexity | Space Complexity |
| :--- | :--- | :--- | :--- | :--- |
| **M1: String Algorithms** *(CO1)* | **Knuth-Morris-Pratt (KMP)** | High-speed lookup of ISO container serials (`MSKU9012347`) in manifest streams | $O(N + M)$ | $O(M)$ |
| | **Z-Algorithm** | Detection of repeated cargo descriptions and periodic sensor streams | $O(N + M)$ | $O(N + M)$ |
| | **Rabin-Karp Matcher** | Multi-window rolling hash search of shipment tracking codes | $O(N + M)$ avg | $O(1)$ |
| | **Aho-Corasick Automaton** | Simultaneous multi-pattern detection of contraband & hazardous alerts (`EXPLOSIVE`, `UN_1993`, `RADIOACTIVE`) | $O(N + M + Z)$ | $O(\Sigma \cdot M)$ |
| **M2: Suffix Structures** *(CO2)* | **Suffix Array (Prefix Doubling)** | Binary search substring indexing of cargo customs records | $O(N \log^2 N)$ | $O(N)$ |
| | **SA-IS Algorithm** | Linear-time suffix array induced sorting for gigabyte manifest files | $\mathbf{O(N)}$ | $O(N)$ |
| | **Kasai's LCP Algorithm** | Linear-time Longest Common Prefix array to find common cargo clauses | $\mathbf{O(N)}$ | $O(N)$ |
| | **Suffix Automaton (DAWG)** | Directed acyclic word graph for instant substring presence and distinct phrase counts | $\mathbf{O(N)}$ constr / $O(M)$ query | $O(N)$ |
| **M3: Advanced Dynamic Programming** *(CO3)* | **Damerau-Levenshtein** | OCR error correction for weather-worn placards (insert, delete, substitute, transpose) | $O(N \cdot M)$ | $O(N \cdot M)$ |
| | **Bitmask DP** | Constrained container subset selection for AGVs under mutual hazard incompatibilities | $O(2^N \cdot N)$ | $O(2^N)$ |
| | **Matrix-Chain Multiplication** | Query join order optimizer for multi-table port telemetry relational databases | $O(N^3)$ | $O(N^2)$ |
| | **Optimal BST (OBST)** | Minimal expected search cost tree for high-frequency gate SKU and tariff code queries | $O(N^3)$ | $O(N^2)$ |
| **M4: Network Flow** *(CO4)* | **Ford-Fulkerson** | Baseline augmenting path cargo flow through port terminal corridors | $O(E \cdot F)$ | $O(V + E)$ |
| | **Edmonds-Karp** | BFS shortest augmenting path for terminal throughput capacity analysis | $O(V \cdot E^2)$ | $O(V + E)$ |
| | **Dinic's Algorithm** | Level graphs & blocking flows for large multi-terminal port networks | $\mathbf{O(V^2 E)}$ | $O(V + E)$ |
| | **Bipartite Matching** | Allocating arriving containers to eligible quay cranes and inspection bays | $O(E \sqrt{V})$ | $O(V + E)$ |
| | **Min-Cut Bottleneck Analysis** | Extraction of critical transfer bottlenecks limiting total port TEU capacity | $O(V + E)$ post-flow | $O(V)$ |
| **M5: NP-Completeness & Reductions** *(CO5)* | **DPLL 3-SAT Solver** | Enforcing strict port regulations (hazardous segregation, stack limits, reefer power) | Exponential worst-case | $O(V + C)$ |
| | **3-SAT $\rightarrow$ CLIQUE Reduction** | Tripartite gadget graph reduction proving computational difficulty of conflict graphs | $O(C)$ | $O(C)$ |
| | **CLIQUE $\rightarrow$ IS $\rightarrow$ VC Pipeline** | Graph complementation and duality for resource conflict scheduling | $O(V^2)$ | $O(V^2)$ |
| | **Vertex-Cover 2-Approximation** | Maximal-matching approximation for minimal security scanner and CCTV camera placement | $\mathbf{O(V + E)}$ (Ratio $\le 2.0$) | $O(V)$ |
| **M6: Randomized & Parallel Algorithms** *(CO6)* | **Randomized QuickSort** | Dutch national flag 3-way partition to rank cargo manifests by priority without worst-case degradation | Expected $O(N \log N)$ | $O(\log N)$ |
| | **Reservoir Sampling (Algorithm R)**| Unbiased uniform sampling of $k$ events from unbounded continuous RFID & AIS sensor streams | $\mathbf{O(N)}$ work, $O(K)$ space | $O(K)$ |
| | **Miller-Rabin Primality Test** | Large integer primality verification for digital manifest seals and cryptographic hash keys | $O(K \log^3 N)$ | $O(\log N)$ |
| | **Blelloch Parallel Scan** | Work-efficient parallel prefix sum for cumulative berth tonnage and loading schedules | $O(N)$ work, $\mathbf{O(\log N)}$ depth | $O(N)$ |
| | **Parallel ForkJoin Reduce** | Multi-threaded tree reduction for port-wide aggregation (total tonnage, peak dwell hours) | $O(N)$ work, $\mathbf{O(\log N)}$ depth | $O(\log N)$ |
| | **Brent's Theorem Simulator** | Evaluates theoretical bounds $T_p \le W/p + D$, speedup limits ($W/D$), and optimal processor allocation | $O(P)$ | $O(P)$ |

---

## 📁 Repository Directory Structure

```
PortLogix/
├── .project                                  <- Eclipse Project Configuration
├── .classpath                                <- Eclipse Classpath (Source: src, Output: bin, JavaSE-21)
├── .settings/
│   └── org.eclipse.jdt.core.prefs            <- Eclipse Compiler Compliance (Java 21)
├── data/
│   ├── sample_manifests.txt                  <- Realistic Bills of Lading, Customs entries, hazard alerts
│   ├── container_records.csv                 <- Container fleet records (ISO IDs, weights, dwell times)
│   └── port_network.txt                      <- Port terminal network topology (nodes, corridors, capacities)
├── src/
│   └── com/portlogix/
│       ├── PortLogixApp.java                 <- Main Application Launcher & Scenario Simulator
│       ├── model/                            <- Domain Models (Container, Vessel, PortFacility, CargoAlert, ShipmentRecord)
│       ├── m1_strings/                       <- Knuth-Morris-Pratt, Z-Algorithm, Rabin-Karp, Aho-Corasick
│       ├── m2_suffix/                        <- SuffixArray, SAIS O(N), KasaiLCP, SuffixAutomaton
│       ├── m3_dp/                            <- DamerauLevenshtein, ContainerBitmaskDP, MatrixChainOptimizer, OptimalBST
│       ├── m4_flow/                          <- FlowEdge, FlowNetwork, FordFulkerson, EdmondsKarp, DinicFlow, BipartiteMatching, MinCutAnalyzer
│       ├── m5_np/                            <- PortSatSolver (DPLL), KarpReductions, VertexCoverApprox
│       ├── m6_parallel/                      <- RandomizedQuickSort, ReservoirSampler, MillerRabinTest, BlellochScan, ParallelReduce, BrentTheoremSimulator
│       ├── benchmark/                        <- ComprehensiveTests (Automated 45-Test Suite)
│       └── gui/                              <- PortLogixGUI (Modern Dark-Themed Swing Desktop Dashboard)
└── README.md                                 <- Detailed documentation & syllabus mapping
```

---

## 🎨 Swing Desktop Dashboard Highlights
The GUI (`PortLogixGUI`) provides visual interactive tabs:
- **String Searching & Security Scanner (M1)**: Live test strings with KMP, Z-Algorithm, Rabin-Karp, and multi-pattern hazard scans.
- **Suffix Indexing & Document Similarity (M2)**: Inspect SA-IS suffix arrays, Kasai LCP arrays, and extract longest shared cargo clauses.
- **Dynamic Programming (M3)**: Interactive OCR typo corrector with confidence score, AGV container packing bitmask selector, MCM parenthesization tree, and OBST hierarchy.
- **Network Flow & Bottlenecks (M4)**: Max-flow throughput calculator (Dinic vs Edmonds-Karp), minimum-cut choke point extraction, and bipartite crane matching.
- **NP-Completeness & Sensor Coverage (M5)**: DPLL 3-SAT solver, step-by-step reduction pipeline (3-SAT $\rightarrow$ CLIQUE $\rightarrow$ IS $\rightarrow$ VC), and 2-approximation scanner placement.
- **Parallel Scans & Big Data Analytics (M6)**: Interactive Blelloch parallel prefix scan visualizer, streaming reservoir sampler, Miller-Rabin primality validator, and Brent's theorem speedup curve table.
